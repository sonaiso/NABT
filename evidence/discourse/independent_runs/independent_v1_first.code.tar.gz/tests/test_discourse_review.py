"""Independent scorer obligations; these do not run the held-out predictions."""
from copy import deepcopy
from hashlib import sha256
import importlib.util
from pathlib import Path
import sys
import unittest

PATH = Path(__file__).resolve().parents[1] / 'tools/discourse_evaluation.py'
spec = importlib.util.spec_from_file_location('discourse_review_evaluator', PATH)
evaluation = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = evaluation
spec.loader.exec_module(evaluation)


def example():
    text = 'حازم حكيم'
    source_id = 'test_source'
    inputs = {'text': text, 'source_id': source_id, 'scope': 'test',
              'context': {'entities': [{'id': 'h', 'name': 'حازم'}], 'closed_reference_scope': True}}
    checksum = sha256(text.encode()).hexdigest()
    def span(a, b):
        return {'source_id': source_id, 'source_sha256': checksum, 'start': a, 'end': b}
    first, gap, second, whole = span(0, 8), span(8, 9), span(9, 17), span(0, 17)
    context = {'entities': [{'id': 'h', 'name': 'حازم', 'gender': 'unknown', 'number': 'unknown', 'kind': 'unknown'}],
               'deixis': [], 'closed_reference_scope': True}
    context_sha = evaluation.digest(context)
    reference = {'origin': 'named', 'surface': 'حازم', 'span': first, 'scope': 'test',
                 'context_sha256': context_sha, 'candidate_entity_ids': ['h'], 'bound_entity_id': 'h'}
    reference['reference_id'] = evaluation.digest(reference)
    rows = []
    for rid, surface, location, pos in [('subject', 'حازم', first, 'PN'), ('predicate', 'حكيم', second, 'N')]:
        rows.append({'reading_id': rid, 'kind': 'noun', 'construction': None, 'class_candidates': [],
                     'stem_span': location, 'stem_surface': surface, 'nun_readings': [],
                     'lexical_features': {'lemma': surface, 'pos': pos},
                     'segmentation': {'parts': [{'span': location, 'surface': surface}]}})
    assignments = []
    for rid, surface, location, role, head in [('subject', 'حازم', first, 'nominal_subject', None),
                                              ('predicate', 'حكيم', second, 'nominal_predicate', first)]:
        assignments.append({'reading_id': rid, 'span': location, 'surface': surface, 'role': role,
            'required_case': 'raf', 'head_span': head, 'activated': True, 'actual_role': role,
            'inflected_case': None, 'local_case': None, 'case_domain': None, 'sign_candidates': []})
    claim = {'predicate': 'حكيم', 'predicate_kind': 'property', 'voice': None, 'args': ['h'],
             'positive': True, 'tense': 'unspecified', 'time': [], 'place': [], 'restriction': []}
    analysis = {'span': whole, 'reading_ids': ['subject', 'predicate'], 'references': [reference],
                'assignments': assignments, 'force': 'ASSERT', 'licensed_syntax': True,
                'references_complete': True, 'rejected_candidate': False, 'assertion_allowed': True,
                'claims': [deepcopy(claim)]}
    analysis['analysis_id'] = evaluation.digest(analysis)
    clause = {'span': whole, 'status': 'LICENSED', 'force': 'ASSERT', 'analyses': [analysis]}
    clause['clause_id'] = evaluation.digest(clause)
    claim['claim_id'] = 'claim'
    claim['proofs'] = [{'analysis_id': analysis['analysis_id'], 'clause_id': clause['clause_id'], 'span': whole}]
    report = {'source_text': text, 'source_id': source_id, 'scope': 'test', 'source_sha256': checksum,
              'world_truth': 'NOT_ESTABLISHED', 'context': {'value': context, 'sha256': context_sha},
              'partition': [{'kind': 'written_run', 'surface': 'حازم', 'span': first},
                            {'kind': 'spacing', 'surface': ' ', 'span': gap},
                            {'kind': 'written_run', 'surface': 'حكيم', 'span': second}],
              'occurrences': [{'surface': row['stem_surface'], 'span': row['stem_span'], 'readings': [row]} for row in rows],
              'derived_readings': [], 'clauses': [clause], 'claims': [claim], 'status': 'LICENSED_DISCOURSE'}
    report['report_id'] = evaluation.digest(report)
    return inputs, report


def rehash(report):
    for clause in report['clauses']:
        for analysis in clause['analyses']:
            analysis['analysis_id'] = evaluation.digest({k: v for k, v in analysis.items() if k != 'analysis_id'})
        clause['clause_id'] = evaluation.digest({k: v for k, v in clause.items() if k != 'clause_id'})
    for claim in report['claims']:
        for proof in claim['proofs']:
            proof['analysis_id'] = report['clauses'][0]['analyses'][0]['analysis_id']
            proof['clause_id'] = report['clauses'][0]['clause_id']
    report['report_id'] = evaluation.digest({k: v for k, v in report.items() if k != 'report_id'})


class DiscourseReviewTests(unittest.TestCase):
    def test_frozen_material_inventory_and_all_predicates_implemented(self):
        freeze, material, inventory = evaluation.load_material()
        self.assertEqual(len(material['cases']), 86)
        self.assertEqual(len(inventory['profiles']['qac_form_holdout']['excluded_verses']), 83)
        self.assertFalse(freeze['new_runtime_or_formal_files_opened_before_freeze'])

    def test_valid_correlated_report(self):
        inputs, report = example()
        evaluation.validate_report(report, inputs)

    def test_signed_claim_cannot_borrow_opposite_analysis(self):
        inputs, report = example()
        report['claims'][0]['positive'] = False
        rehash(report)
        with self.assertRaisesRegex(ValueError, 'Claim proof'):
            evaluation.validate_report(report, inputs)

    def test_qualification_cannot_be_erased_from_claim_proof(self):
        inputs, report = example()
        report['clauses'][0]['analyses'][0]['claims'][0]['time'] = ['أمس']
        rehash(report)
        with self.assertRaisesRegex(ValueError, 'Claim proof'):
            evaluation.validate_report(report, inputs)

    def test_property_event_and_voice_are_not_equal(self):
        _, report = example()
        claim = report['claims'][0]
        for field, value in [('predicate_kind', 'event'), ('voice', 'passive'), ('tense', 'past'),
                             ('place', ['p']), ('restriction', ['only'])]:
            other = {**deepcopy(claim), field: value}
            self.assertNotEqual(evaluation.claim_key(claim), evaluation.claim_key(other))

    def test_integer_is_not_claim_polarity(self):
        _, report = example()
        report['claims'][0]['positive'] = 1
        with self.assertRaises(ValueError):
            evaluation.claim_view(report['claims'][0])

    def test_role_required_case_is_checked_independently(self):
        inputs, report = example()
        report['clauses'][0]['analyses'][0]['assignments'][1]['required_case'] = 'jarr'
        rehash(report)
        with self.assertRaisesRegex(ValueError, 'Role/case'):
            evaluation.validate_report(report, inputs)

    def test_predicate_head_cannot_be_reassigned_to_itself(self):
        inputs, report = example()
        a = report['clauses'][0]['analyses'][0]['assignments'][1]
        a['head_span'] = a['span']
        rehash(report)
        with self.assertRaisesRegex(ValueError, 'Predicate governor'):
            evaluation.validate_report(report, inputs)

    def test_unresolved_alternative_blocks_accepted_claim(self):
        inputs, report = example()
        a = deepcopy(report['clauses'][0]['analyses'][0])
        a['references_complete'] = False
        a['assertion_allowed'] = False
        a['claims'][0]['args'] = [None]
        report['clauses'][0]['analyses'].append(a)
        rehash(report)
        with self.assertRaisesRegex(ValueError, 'unresolved alternative'):
            evaluation.validate_report(report, inputs)

    def test_complete_nun_cluster_required(self):
        text = 'يَحْزَنُونَ'
        raw = text.encode()
        start = raw.rindex('ن'.encode())
        inputs = {'text': text, 'source_id': 'nun'}
        span = {'source_id': 'nun', 'source_sha256': sha256(raw).hexdigest(), 'start': start, 'end': len(raw)}
        nun = {'span': span, 'surface': 'نَ'}
        self.assertTrue(evaluation.nun_span_valid(nun, inputs))
        nun['span'] = {**span, 'end': start + len('ن'.encode())}
        nun['surface'] = 'ن'
        self.assertFalse(evaluation.nun_span_valid(nun, inputs))

    def test_binding_instantiation_preserves_all_other_fields(self):
        _, report = example()
        pattern = deepcopy(report['claims'][0])
        pattern['args'] = ['?person']
        pattern['time'] = ['?time']
        bound = evaluation.instantiate(pattern, {'?person': 'h', '?time': 'أَمْس'})
        self.assertEqual(bound['time'], ['أمس'])
        self.assertEqual(bound['predicate_kind'], 'property')
        with self.assertRaises(ValueError):
            evaluation.instantiate(pattern, {'?person': 'h'})
        with self.assertRaises(ValueError):
            evaluation.instantiate(pattern, {'?person': 'h', '?time': 'أمس', '?other': 'h'})


if __name__ == '__main__':
    unittest.main()
