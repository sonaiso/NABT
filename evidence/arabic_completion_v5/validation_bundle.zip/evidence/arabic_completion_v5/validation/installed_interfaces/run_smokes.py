#!/usr/bin/env python3
"""Additional authored interface checks against the independently installed wheel.

The checkout is used only to locate frozen source inputs and packaging receipts.
All public calls execute the installed wheel outside the checkout, with
PYTHONPATH/PYTHONHOME removed. These are interface checks, not Arabic accuracy.
"""
from hashlib import sha256
import json
import os
from pathlib import Path
import shutil
import subprocess
import tempfile

ROOT=Path(__file__).resolve().parents[4]
OUTPUT=Path(__file__).resolve().parent
PACKAGE=OUTPUT.parent/'installed_package'


def digest(raw): return sha256(raw).hexdigest()


def main():
    if (OUTPUT/'validation.json').exists(): raise ValueError('Never replace recorded smokes')
    validation=json.loads((PACKAGE/'validation.json').read_bytes())
    assert validation['version']=='0.19.0a1' and validation['smoke_check_count']==49
    install=json.loads((PACKAGE/'logs/install-wheel.command.json').read_bytes())
    python=Path(install['argv'][0]);nabt=python.parent/'nabt'
    assert python.is_file() and nabt.is_file()
    work=Path(tempfile.mkdtemp(prefix='nabt-installed-interfaces-',dir='/tmp'))
    assert not work.is_relative_to(ROOT)
    source=ROOT/'evidence/classical_language/sources/maqayis.txt'
    raw=source.read_bytes();assert digest(raw)=='7f71af0dfe056cb84e7da24657fa13edc6e8061ca1980eed7f6c196bd18b5689'
    (work/'maqayis.txt').write_bytes(raw)
    wrong=b'!'+raw[1:];assert len(wrong)==len(raw) and wrong!=raw
    (work/'maqayis-tampered.txt').write_bytes(wrong)
    env=dict(os.environ)
    for name in ('PYTHONPATH','PYTHONHOME'):env.pop(name,None)
    env.update(PYTHONNOUSERSITE='1',PIP_CONFIG_FILE=os.devnull)
    (OUTPUT/'logs').mkdir()
    records=[]
    def call(name,args,code=0,stream='stdout',json_output=True):
        p=subprocess.run([str(x) for x in args],cwd=work,env=env,capture_output=True,timeout=120)
        record={'id':name,'argv':[str(x) for x in args],'cwd':str(work),'exit':p.returncode,'expected_exit':code}
        for label,data in [('stdout',p.stdout),('stderr',p.stderr)]:
            path=OUTPUT/'logs'/(name+'.'+label)
            with path.open('xb') as out:out.write(data)
            record[label]={'path':str(path.relative_to(OUTPUT)),'bytes':len(data),'sha256':digest(data)}
        assert p.returncode==code,(name,p.returncode,p.stderr.decode())
        value=getattr(p,stream).decode()
        record['passed']=True;records.append(record)
        return json.loads(value) if json_output else value
    version=call('version',[nabt,'--version'],json_output=False)
    assert version.strip()=='0.19.0a1'
    origin=call('installed-origin',[python,'-I','-c',
        'import json,nabt,nabt.phonological_modes,nabt.source_lexicon; from pathlib import Path; print(json.dumps({"version":nabt.__version__,"package":str(Path(nabt.__file__).resolve()),"phonology":str(Path(nabt.phonological_modes.__file__).resolve()),"lexicon":str(Path(nabt.source_lexicon.__file__).resolve())}))'])
    assert origin['version']=='0.19.0a1'
    assert all(Path(origin[k]).is_relative_to(python.parent.parent) and not Path(origin[k]).is_relative_to(ROOT)
               for k in ('package','phonology','lexicon'))
    catalog=call('phonology-catalog',[nabt,'phonology-catalog'])
    assert len(catalog['examples'])==20 and len(catalog['passages'])==20
    assert any(row['example_id']=='idrib' for row in catalog['examples'])
    initial=call('phonology-ibtida',[nabt,'phonology','idrib'])
    assert initial['status']=='CONDITIONAL_PROJECTION' and initial['written_form']=='اِضْرِبْ'
    assert initial['alternatives'][0]['segments']==['ʔ','i','ḍ','r','i','b']
    assert initial['acoustic_validation'] is False and initial['complete_for_arabic'] is False
    connected=call('phonology-wasl',[nabt,'phonology','idrib','--start','wasl'])
    assert connected['status']=='CONDITIONAL_PROJECTION' and connected['written_form']=='اِضْرِبْ'
    assert connected['alternatives'][0]['segments']==['ḍ','r','i','b']
    unknown=call('phonology-unknown',[nabt,'phonology','__no_source_example__'],3)
    assert unknown['status']=='UNKNOWN' and unknown['reason']=='outside_source_example_catalog'
    found=call('source-lexicon-known',[nabt,'source-lexicon','--source','maqayis','--file','maqayis.txt','--root','كتب'])
    assert found['status']=='FOUND_SOURCE_HEADINGS' and found['alternatives']
    assert found['reading_licensed'] is False and found['syntactic_licence'] is False and found['world_truth_asserted'] is False
    missing=call('source-lexicon-not-indexed',[nabt,'source-lexicon','--source','maqayis','--file','maqayis.txt','--root','__no_heading__'],3)
    assert missing['status']=='NOT_INDEXED' and missing['alternatives']==[]
    mismatch=call('source-lexicon-wrong-hash',[nabt,'source-lexicon','--source','maqayis','--file','maqayis-tampered.txt','--root','كتب'],3,stream='stderr')
    assert mismatch['status']=='DEFER' and mismatch['code']=='SOURCE_IDENTITY_MISMATCH'
    inventory=call('source-lexicon-inventory',[nabt,'source-lexicon','--source','maqayis','--file','maqayis.txt'])
    assert inventory['heading_blocks']==5605 and inventory['source_bytes_partitioned'] is True
    assert inventory['linguistic_completeness_denominator'] is None and inventory['all_senses_enumerated'] is False
    result={'schema':'nabt.installed-classical-interface-smokes.v1','valid':True,'version':'0.19.0a1',
        'runtime_freeze_sha256':digest((ROOT/'evidence/arabic_completion_v5/code_freeze_v1.json').read_bytes()),
        'base_validation_sha256':digest((PACKAGE/'validation.json').read_bytes()),'base_smoke_count':49,
        'additional_smoke_count':len(records),'total_smoke_count':49+len(records),
        'wheel_sha256':validation['wheel']['sha256'],'package_origin':origin,'outside_checkout':True,
        'source_sha256':digest(raw),'same_length_tampered_source_sha256':digest(wrong),
        'source_mutation':'Replace only first byte with !; preserve input length.',
        'cases':records,'scope':'Installed public interface and source-identity checks; not a blind benchmark, acoustic measurement, or universal Arabic completeness.'}
    with (OUTPUT/'validation.json').open('x',encoding='utf-8') as out:json.dump(result,out,ensure_ascii=False,indent=2);out.write('\n')
    rows=[]
    for p in sorted(OUTPUT.rglob('*')):
        if p.is_file():
            data=p.read_bytes();rows.append({'path':str(p.relative_to(OUTPUT)),'bytes':len(data),'sha256':digest(data)})
    with (OUTPUT/'manifest.json').open('x') as out:json.dump({'files':rows},out,indent=2);out.write('\n')
    print(json.dumps({k:result[k] for k in ('valid','version','base_smoke_count','additional_smoke_count','total_smoke_count','outside_checkout')}))

if __name__=='__main__':main()
