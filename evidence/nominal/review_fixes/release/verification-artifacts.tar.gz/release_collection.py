from __future__ import annotations
from datetime import datetime, timezone
from hashlib import sha256
import gzip, io, json, platform, re, subprocess, sys, tarfile
from pathlib import Path
ROOT=Path('/workspace/scratch/93a907621097/NABT')
INPUT=ROOT/'artifacts/local/nominal-review-release'
OUT=ROOT/'evidence/nominal/review_fixes/release'
sys.path.insert(0,str(ROOT/'tools'))
from text_evaluation.integrity import verify_code_freeze

def require(ok,message):
    if not ok: raise ValueError(message)
def load(path): return json.loads(path.read_text())
def digest(raw): return sha256(raw).hexdigest()
def record(path,base=ROOT):
    raw=path.read_bytes()
    return {'path':str(path.relative_to(base)),'bytes':len(raw),'sha256':digest(raw)}
def write(path,value):
    require(not path.exists(),'Refusing to overwrite '+str(path))
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n')
def report(name):return load(INPUT/'verified'/name)

require(not OUT.exists(),'Release evidence already exists')
freeze_path=ROOT/'evidence/nominal/code_freeze_v2.json'
freeze=verify_code_freeze(freeze_path,ROOT)
require(len(freeze['files'])==52,'Unexpected runtime inventory')
archive=freeze_path.parent/freeze['archive_filename']
require(digest(archive.read_bytes())==freeze['archive_sha256'],'Runtime archive digest differs')
rows={r['path']:r for r in freeze['files']}
with tarfile.open(archive,'r:gz') as source:
    require(set(source.getnames())==set(rows),'Runtime archive inventory differs')
    for member in source.getmembers():
        raw=source.extractfile(member).read()
        require(len(raw)==rows[member.name]['bytes'] and digest(raw)==rows[member.name]['sha256'],'Runtime archive member differs')
exit_record=load(INPUT/'gate-exit.json')
require(exit_record['runner_observed_exit_code']==0,'Full check failed')
log=(INPUT/'make-check.log').read_text()
test=re.search(r'Ran (\d+) tests in ([0-9.]+)s\n\nOK\n',log)
require(test and int(test[1])==578,'Test result not found')
require(json.loads(log.rsplit('python3 tools/check_integrity.py\n',1)[1])['ok'] is True,'Final integrity gate failed')
axioms=report('axioms.json'); nominal=report('nominal-conformance.json'); measure=report('nominal-regression.json')
require(axioms['ok'] and axioms['theorem_count']==520,'Axiom audit failed')
require(nominal['ok'] and measure['passed'] and measure['raw_score']=={'passed':184,'total':184},'Nominal gates failed')
require(measure['runtime_unchanged_during_evaluation'],'Runtime changed during evaluation')
package=load(INPUT/'packaging/validation.json')
require(package['ok'],'Wheel gate failed')
require(package['correspondence']['all_package_bytes_match_freeze'],'Installed package mismatch')
review_before=load(ROOT/'evidence/nominal/review_fixes/before_result_v1.json')
review_after=load(ROOT/'evidence/nominal/review_fixes/after_result_v1.json')
require(review_before['score']=={'passed':65,'total':99} and review_after['score']=={'passed':99,'total':99} and review_after['passed'],'Review-fix regression result differs')
require(review_before['test_file_sha256']==review_after['test_file_sha256'] and review_before['material_sha256']==review_after['material_sha256'],'Review oracle changed between measurements')
require(review_after['runtime_unchanged_during_measurement'],'Runtime changed during review measurement')
require(review_after['test_file_sha256']==digest((ROOT/'tests/test_counting_review_fixes.py').read_bytes()),'Current review test differs from measured test')
require({r['path']:r for r in review_after['runtime_snapshot']['files']}==rows,'Review measurement differs from frozen runtime')
head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip()
for row in freeze['files']:
    raw=subprocess.check_output(['git','show',head+':'+row['path']],cwd=ROOT)
    require(digest(raw)==row['sha256'],'Implementation commit differs from runtime')
paths=set()
for folder in ('tests','tools'):
    paths.update(p for p in (ROOT/folder).rglob('*.py') if '__pycache__' not in p.parts)
paths.update(p for p in (ROOT/'formal').rglob('*.lean') if '.lake' not in p.parts)
paths.update(ROOT/p for p in ('formal/lean-toolchain','formal/theorems.json','formal/lake-manifest.json','Makefile','.github/workflows/ci.yml','README.md','LICENSE'))
paths={p for p in paths if p.is_file()}
verification=[]
for path in sorted(paths):
    row=record(path)
    committed=subprocess.check_output(['git','show',head+':'+row['path']],cwd=ROOT)
    require(digest(committed)==row['sha256'],'Verification source differs from implementation commit: '+row['path'])
    verification.append(row)
OUT.mkdir(parents=True)
write(OUT/'verification-source-manifest.json',{'schema':'nabt.nominal.verification-sources.v1','implementation_commit':head,'files':verification})
# Preserve actual logs, reports, and the wheel built after the final README update.
source_files=sorted(p for p in INPUT.rglob('*') if p.is_file())
archive_path=OUT/'verification-artifacts.tar.gz'
with archive_path.open('xb') as handle:
    with gzip.GzipFile(filename='',mode='wb',fileobj=handle,mtime=0) as compressed:
        with tarfile.open(mode='w',fileobj=compressed) as target:
            for path in source_files:
                raw=path.read_bytes(); info=tarfile.TarInfo(path.relative_to(INPUT).as_posix())
                info.size=len(raw); info.mode=0o644; info.mtime=0
                target.addfile(info,io.BytesIO(raw))
artifact_rows=[record(p,INPUT) for p in source_files]
write(OUT/'verification-artifact-manifest.json',{'schema':'nabt.nominal.verification-artifacts.v1','archive':record(archive_path),'files':artifact_rows})
for name in ('nominal-conformance.json','nominal-regression.json','axioms.json'):
    (OUT/name).write_bytes((INPUT/'verified'/name).read_bytes())
(OUT/'wheel-validation.json').write_bytes((INPUT/'packaging/validation.json').read_bytes())
(OUT/'gate-exit.json').write_bytes((INPUT/'gate-exit.json').read_bytes())
(OUT/'make-check.log').write_bytes((INPUT/'make-check.log').read_bytes())
first_path=ROOT/'evidence/nominal/independent_first_run_v1.json'
first=load(first_path)
first_runtime={r['path']:r['sha256'] for r in first['code_snapshot']['files']}
first_diff=[r['path'] for r in freeze['files'] if first_runtime.get(r['path'])!=r['sha256']]
word=report('word-regression.json');morph=report('morphology-regression.json')
arabic=report('arabic-regression/receipt.json')
result={
 'schema':'nabt.nominal.release-validation.v1','recorded_at_utc':datetime.now(timezone.utc).isoformat(),
 'package_version':'0.11.0a2','status':'BOUNDED_VALIDATION_PASS',
 'repository_base_commit':'d2013d937fae0336f38c9a49ffd5c8b03858f7fc','implementation_commit':head,
 'release_commit':None,'release_commit_note':'The following evidence-only commit contains this record; runtime and verification sources are pinned without a recursive commit hash.',
 'runtime':{'freeze_version':'nominal_v2','manifest':record(freeze_path),'snapshot_sha256':freeze['snapshot_sha256'],'file_count':52,'archive':record(archive),'current_bytes_match_frozen_inventory':True,'inventory_is_exact_authoritative_runtime':True,'archive_members_match_frozen_inventory':True},
 'verification_sources':{**record(OUT/'verification-source-manifest.json'),'file_count':len(verification),'all_match_implementation_commit':True},
 'full_check':{'outcome':'PASS','runner_observed_exit_code':0,'tests_run':int(test[1]),'failures':0,'test_seconds':float(test[2]),'command':exit_record['command'],'log':record(OUT/'make-check.log'),'lean_toolchain':(ROOT/'formal/lean-toolchain').read_text().strip(),'runtime_environment':{'python':sys.version,'platform':platform.platform()}},
 'formal_audit':{'theorem_count':520,'new_theorems':44,'observed_axioms':axioms['observed_axioms'],'all_nabt_declarations_scanned':axioms['all_nabt_declarations_scanned'],'project_axioms_allowed':False,'report':record(OUT/'axioms.json')},
 'nominal_conformance':{'report':record(OUT/'nominal-conformance.json'),'result':nominal},
 'independent_evaluation':{'first_run':record(first_path),'first_score':first['raw_score'],'first_runtime_differences_from_release':first_diff,'difference_reason':'Source and written-run segmentation identities were strengthened for a1; a2 then corrected decimal canonicality and internal separator guards and advanced the package version. Gold and the nominal evaluator stayed fixed.','release_report':record(OUT/'nominal-regression.json'),'release_score':measure['raw_score'],'task_scores':measure['task_scores'],'material_sha256':measure['material_sha256'],'protocol_sha256':measure['protocol_sha256'],'authored_source_informed_cases_not_natural_corpus':True,'runtime_unchanged_during_release_evaluation':True},
 'installed_wheel':{'report':record(OUT/'wheel-validation.json'),'package_files_verified':51,'source_freeze_files_verified':52,'cli_smoke_checks':15,'built_after_final_readme_results_update':True},
 'review_fixes':{'baseline_commit':'a9efdd7e5a5f9b57aeabce9d3d57fd4bf8a316c2','comment_urls':['https://github.com/sonaiso/NABT/pull/9#discussion_r4359983718','https://github.com/sonaiso/NABT/pull/9#discussion_r4359983758'],'evidence_directory':'evidence/nominal/review_fixes','new_regression_cases':99,'before_score':review_before['score'],'after_score':review_after['score'],'before_report':record(ROOT/'evidence/nominal/review_fixes/before_result_v1.json'),'after_report':record(ROOT/'evidence/nominal/review_fixes/after_result_v1.json'),'same_formal_law_and_declared_language':True,'prior_a1_release_preserved':record(ROOT/'evidence/nominal/release/validation.json')},
 'older_coverage_preserved':{'word':word['summary'],'morphology':morph['summary'],'arabic_syntax':arabic['summary'],'note':'Old bounded deficits remain published. A passing regression gate does not relabel them as full linguistic coverage.'},
 'verification_archive':record(archive_path),'verification_artifact_manifest':record(OUT/'verification-artifact-manifest.json'),
 'limits':['Conditional source-relative feature laws do not establish lexical or world truth.','Closed pronoun and unmarked numeral inventories do not exhaust Arabic homographs or numeral spellings.','The root bridge classifies formal candidates; weak-form realization and attested root recovery remain open.','Grammatical segmentation, nun type, attachment, actual role and actual case are not inferred by this feature layer.','The observed upstream source audit is separate from a rebuild of upstream Lean repositories.']}
write(OUT/'validation.json',result)
(OUT/'README.md').write_text('# Nominal review-fix release validation\n\nVersion 0.11.0a2: 578 tests, 520 audited theorems, 184/184 unchanged authored independent cases, 99/99 additional review-regression cases, full make check exit 0, and installed-wheel correspondence.\n\nvalidation.json records exact runtime and verification inputs. verification-artifacts.tar.gz retains full logs, reports, and the final wheel build; verification-artifact-manifest.json lists every member and digest. The package was built after the README was updated, and all 51 package files match the new runtime freeze. The a1 freeze, release, and first independent measurement remain unchanged. Review-fix cases are a separate post-review regression set and do not increase the original 184-case score. Prior corpus coverage gaps remain visible.\n')
write(OUT/'manifest.json',{'schema':'nabt.nominal.release-files.v1','files':[record(p,OUT) for p in sorted(OUT.iterdir()) if p.is_file()]})
print(json.dumps({'validation':record(OUT/'validation.json'),'implementation_commit':head,'verification_source_count':len(verification),'verification_artifact_count':len(artifact_rows),'archive':record(archive_path)},indent=2))
