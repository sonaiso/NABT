# Nominal release installed-wheel verification

This record verifies the `nabt-machine` **0.11.0a1** wheel built from the nominal
runtime freeze. It is separate from the release-wide `make check` record.

## Result

- Current source: **52/52** files match the manifest by byte length and SHA-256
  before and after the packaging run. The frozen archive and all its 52 members
  were also verified before populating the build staging tree.
- Wheel and installed package: **51/51** authoritative package files match;
  no additional package files except generated Python bytecode. The remaining
  frozen file, `pyproject.toml`, is build input rather than an installed file;
  distribution name, version, Python requirement, dependencies, and console
  entry point were checked against it.
- The build used the existing Python 3.12.14, pip 26.2.1, setuptools 84.0.0 and
  wheel 0.48.0 with `--no-build-isolation --no-deps --no-index`.
- A fresh virtual environment and command working directory were created under
  `/tmp`, outside the checkout. `PYTHONPATH` and `PYTHONHOME` were removed;
  installation inspection and numeric decoding used Python isolated mode.
- All **15 CLI smoke cases** passed, covering all **11 new commands**, plus
  a separate CLI version check and installed-API exact numeric roundtrip.
- The four verifiers returned `VERIFIED`, `valid: true`, exit **0** with the
  original sources. Withdrawing the lexical source from the nominal and
  counted-phrase verification returned `REJECT`, `valid: false`, exit **2**.
- Nominal reading, counted-phrase reading, encoded nominal reading and the
  unsupported cardinal value 101 returned the intended **DEFER / exit 3**.
  The last result is a structured bounded-domain response, not an exception
  escaping the command boundary.

## Pins

| Item | SHA-256 |
|---|---|
| Runtime snapshot inventory | `c00458629fcd08a6cefb616d0fb1caaec5958996b0532043d0fd1a92d922740a` |
| Runtime archive | `6d86c0709c97a89375fc9ff498d1576585c3e432831c7ac17cfc1eb75c2f2724` |
| Installed nominal table | `0b0218d75329e1b04302ebdf875a4a43db772d4650b3415bc767f2a6a96d07a8` |
| Built wheel | `c452f4602bfceedc7a7078562aee805493b2bb314e08d763fff69adcf4e91f4e` |

## Artifacts and scope

`validation.json` records the results, exact temporary installation origin,
tool versions, source examples, pins, and build-documentation inputs.
`commands.json` records every invocation and exit code. `logs/` contains raw
stdout and stderr; `results/` contains JSON command results; `sources/` preserves
the three source examples. `installed-files.json` records installed file hashes.
`wheel/` contains the tested wheel. `manifest.json` hashes these artifacts.
`run_packaging_validation.py` is the standard-library driver used for this run.

The build staging tree was populated from the verified frozen runtime archive.
The current README and license were copied as distribution documentation, with
their distinct hashes recorded; they are outside the runtime freeze. No source,
test, gate, CI, historical freeze or gold file was changed by this check.

Successful replay establishes exact source-bound reconstruction. These bounded
examples do not establish unrestricted Arabic recognition, attested roots,
actual case/role, construction truth, world cardinality, or ordinal meaning.
The independent evaluation gold was not inspected or rerun here.
