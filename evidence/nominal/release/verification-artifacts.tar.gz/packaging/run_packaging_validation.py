"""Build and smoke the pinned nominal release without importing the checkout.

This local release record is not a replacement for make check or the independent
evaluation. It needs only the existing Python, pip, setuptools and wheel tools.
"""

from __future__ import annotations

import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import tomllib
from datetime import datetime, timezone
from email.parser import BytesParser
from zipfile import ZipFile


REPO = Path(__file__).resolve().parents[4]
OUT = Path(__file__).resolve().parent
EXPECTED_VERSION = "0.11.0a1"
EXPECTED_SNAPSHOT = "c00458629fcd08a6cefb616d0fb1caaec5958996b0532043d0fd1a92d922740a"
EXPECTED_TABLE = "0b0218d75329e1b04302ebdf875a4a43db772d4650b3415bc767f2a6a96d07a8"


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def main():
    freeze_path = REPO / "evidence/nominal/code_freeze_v1.json"
    freeze_bytes = freeze_path.read_bytes()
    freeze = json.loads(freeze_bytes)
    require(freeze["snapshot_sha256"] == EXPECTED_SNAPSHOT, "Unexpected freeze")
    require(digest(json.dumps(freeze["files"], sort_keys=True, separators=(",", ":")).encode()) == EXPECTED_SNAPSHOT,
            "Freeze inventory digest mismatch")
    require(len(freeze["files"]) == 52, "Unexpected freeze file count")
    source_rows = {r["path"]: r for r in freeze["files"]}
    package_rows = {p.removeprefix("src/"): r for p, r in source_rows.items() if p.startswith("src/")}
    require(len(package_rows) == 51, "Unexpected package file count")

    def verify_source():
        for path, row in source_rows.items():
            data = (REPO / path).read_bytes()
            require(len(data) == row["bytes"] and digest(data) == row["sha256"], f"Current source mismatch: {path}")
        candidates = set(REPO.glob("src/**/*.py")) | set(REPO.glob("src/**/*.json")) | set(REPO.glob("src/**/*.txt")) | {REPO / "pyproject.toml"}
        actual = {str(p.relative_to(REPO)) for p in candidates
                  if not any(part.endswith((".egg-info", ".dist-info")) for part in p.relative_to(REPO).parts[:-1])}
        require(actual == set(source_rows), "Current authoritative source inventory mismatch")

    verify_source()
    archive_path = freeze_path.with_name(freeze["archive_filename"])
    require(digest(archive_path.read_bytes()) == freeze["archive_sha256"], "Runtime archive digest mismatch")
    work = Path(tempfile.mkdtemp(prefix="nabt-nominal-packaging-"))
    stage = work / "frozen-source"
    cwd = work / "smoke"
    stage.mkdir()
    cwd.mkdir()
    (OUT / "logs").mkdir(exist_ok=True)
    (OUT / "results").mkdir(exist_ok=True)
    (OUT / "sources").mkdir(exist_ok=True)
    (OUT / "wheel").mkdir(exist_ok=True)
    with tarfile.open(archive_path, "r:gz") as archive:
        members = archive.getmembers()
        require(len(members) == 52 and {m.name for m in members} == set(source_rows), "Runtime archive inventory mismatch")
        for member in members:
            require(member.isfile(), f"Non-file in runtime archive: {member.name}")
            data = archive.extractfile(member).read()
            row = source_rows[member.name]
            require(digest(data) == row["sha256"] and len(data) == row["bytes"], f"Archive member mismatch: {member.name}")
            target = stage / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    build_extras = []
    for name in ("README.md", "LICENSE"):
        data = (REPO / name).read_bytes()
        (stage / name).write_bytes(data)
        build_extras.append({"path": name, "bytes": len(data), "sha256": digest(data),
                             "scope": "distribution documentation, outside the 52-file runtime freeze"})

    env = dict(os.environ)
    for name in ("PYTHONPATH", "PYTHONHOME"):
        env.pop(name, None)
    env.update(PIP_CONFIG_FILE=os.devnull, PIP_DISABLE_PIP_VERSION_CHECK="1", PYTHONNOUSERSITE="1")
    commands = []

    def run(name, argv, expected=0, directory=cwd):
        result = subprocess.run([str(x) for x in argv], cwd=directory, env=env, capture_output=True, timeout=180)
        stdout = OUT / "logs" / (name + ".stdout")
        stderr = OUT / "logs" / (name + ".stderr")
        stdout.write_bytes(result.stdout)
        stderr.write_bytes(result.stderr)
        record = {"name": name, "argv": [str(x) for x in argv], "cwd": str(directory),
                  "expected_exit_code": expected, "exit_code": result.returncode,
                  "stdout": str(stdout.relative_to(OUT)), "stderr": str(stderr.relative_to(OUT))}
        commands.append(record)
        write_json(OUT / "commands.json", commands)
        require(result.returncode == expected, f"{name}: exit {result.returncode}, expected {expected}; see {stderr}")
        return result

    run("build-wheel", [sys.executable, "-m", "pip", "wheel", stage, "--no-build-isolation", "--no-deps", "--no-index",
                         "--wheel-dir", OUT / "wheel"])
    wheels = list((OUT / "wheel").glob("*.whl"))
    require(len(wheels) == 1, "Expected exactly one built wheel")
    wheel = wheels[0]
    require(wheel.name == "nabt_machine-0.11.0a1-py3-none-any.whl", "Unexpected wheel identity")
    project = tomllib.loads((stage / "pyproject.toml").read_text())["project"]
    require(project["version"] == EXPECTED_VERSION, "Unexpected project version")
    with ZipFile(wheel) as zf:
        actual_package = {n for n in zf.namelist() if n.startswith("nabt/") and not n.endswith("/")}
        require(actual_package == set(package_rows), "Wheel package inventory mismatch")
        for path, row in package_rows.items():
            data = zf.read(path)
            require(len(data) == row["bytes"] and digest(data) == row["sha256"], f"Wheel member mismatch: {path}")
        metadata_path = "nabt_machine-0.11.0a1.dist-info/METADATA"
        metadata = BytesParser().parsebytes(zf.read(metadata_path))
        require(metadata["Name"] == project["name"], "Wheel distribution name mismatch")
        require(metadata["Version"] == project["version"], "Wheel distribution version mismatch")
        require(metadata["Requires-Python"] == project["requires-python"], "Wheel Python requirement mismatch")
        require(metadata.get_all("Requires-Dist", []) == project["dependencies"], "Wheel dependencies mismatch")
    venv = work / "venv"
    run("create-venv", [sys.executable, "-m", "venv", venv])
    python = venv / "bin/python"
    nabt = venv / "bin/nabt"
    run("install-wheel", [python, "-m", "pip", "install", "--no-index", "--no-deps", wheel])
    inspection = r'''
import hashlib, importlib.metadata as md, json, pathlib, sys
import nabt
distribution = md.distribution("nabt-machine")
package = pathlib.Path(nabt.__file__).parent
files = []
for path in sorted(package.rglob("*")):
    if path.is_file() and "__pycache__" not in path.parts:
        raw = path.read_bytes()
        files.append({"path": "nabt/" + str(path.relative_to(package)), "bytes": len(raw),
                      "sha256": hashlib.sha256(raw).hexdigest()})
print(json.dumps({"distribution_version": distribution.version, "module_version": nabt.__version__,
 "module_origin": nabt.__file__, "python": sys.executable, "prefix": sys.prefix,
 "requires_python": distribution.metadata["Requires-Python"],
 "requires_dist": distribution.requires or [], "files": files,
 "entry_points": [{"name": ep.name, "group": ep.group, "value": ep.value} for ep in distribution.entry_points]}, indent=2))
'''
    installed = json.loads(run("inspect-install", [python, "-I", "-c", inspection]).stdout)
    require(installed["distribution_version"] == EXPECTED_VERSION and installed["module_version"] == EXPECTED_VERSION,
            "Installed version mismatch")
    require(Path(installed["module_origin"]).is_relative_to(venv), "Imported checkout rather than isolated installation")
    require(installed["requires_python"] == project["requires-python"] and installed["requires_dist"] == project["dependencies"],
            "Installed metadata mismatch")
    require(installed["entry_points"] == [{"name": "nabt", "group": "console_scripts", "value": "nabt.cli:main"}],
            "Installed entry point mismatch")
    observed = {r["path"]: r for r in installed["files"]}
    require(set(observed) == set(package_rows), "Installed package inventory mismatch")
    for path, row in package_rows.items():
        require(observed[path]["bytes"] == row["bytes"] and observed[path]["sha256"] == row["sha256"],
                f"Installed file mismatch: {path}")
    require(observed["nabt/data/nominal_evidence.json"]["sha256"] == EXPECTED_TABLE, "Installed law table mismatch")
    write_json(OUT / "installed-files.json", installed)

    sources = []
    for source_name in ("nominal.txt", "nominal_assertions.txt", "count_phrase.txt"):
        data = (REPO / "examples" / source_name).read_bytes()
        (cwd / source_name).write_bytes(data)
        (OUT / "sources" / source_name).write_bytes(data)
        sources.append({"source": "examples/" + source_name, "bytes": len(data), "sha256": digest(data)})
    smokes = []

    def smoke(name, args, expected, status=None, valid=None, stderr_json=False):
        result = run(name, [nabt, *args], expected)
        raw = result.stderr if stderr_json else result.stdout
        payload = json.loads(raw)
        if status is not None:
            require(payload.get("status") == status, f"{name}: unexpected status")
        if valid is not None:
            require(payload.get("valid") is valid, f"{name}: unexpected validity")
        if not stderr_json:
            require(result.stderr == b"", f"{name}: unexpected stderr")
        require(b"Traceback" not in result.stderr, f"{name}: unhandled failure")
        path = OUT / "results" / (name + ".json")
        path.write_bytes(raw)
        (cwd / (name + ".json")).write_bytes(raw)
        smokes.append({"name": name, "argv": args, "exit_code": result.returncode,
                       "expected_exit_code": expected, "status": payload.get("status"),
                       "valid": payload.get("valid"), "result": str(path.relative_to(OUT))})
        return payload

    require(run("version", [nabt, "--version"]).stdout.decode().strip() == EXPECTED_VERSION, "CLI version mismatch")
    catalog = smoke("nominal-catalog", ["nominal-catalog"], 0)
    require(catalog["table"]["law_id"] == "nabt.nominal-evidence.v1", "Unexpected installed catalog")
    smoke("weak-root-profile", ["weak-root-profile", "روي"], 0, "CONDITIONAL_CLASSIFICATION")
    rule = smoke("number-rule", ["number-rule", "3", "masculine"], 0, "CONDITIONAL_RULE")
    require(rule["counted_number"] == "plural" and rule["counted_case"] == "genitive", "Cardinal smoke mismatch")
    smoke("read-nominal-facts", ["read-nominal-facts", "nominal_assertions.txt"], 0, "READ")
    smoke("verify-nominal-facts", ["verify-nominal-facts", "read-nominal-facts.json", "--source", "nominal_assertions.txt"], 0, "VERIFIED", True)
    report = smoke("read-nominal", ["read-nominal", "nominal.txt", "--lexical-source", "nominal_assertions.txt"], 3, "DEFER")
    smoke("verify-nominal", ["verify-nominal", "read-nominal.json", "--source", "nominal.txt", "--lexical-source", "nominal_assertions.txt"], 0, "VERIFIED", True)
    smoke("withdraw-nominal-lexical-source", ["verify-nominal", "read-nominal.json", "--source", "nominal.txt"], 2, "REJECT", False)
    smoke("count-source-units", ["count-source-units", "nominal.txt"], 0, "READ")
    smoke("verify-source-count", ["verify-source-count", "count-source-units.json", "--source", "nominal.txt"], 0, "VERIFIED", True)
    counted = smoke("read-count-phrase", ["read-count-phrase", "count_phrase.txt", "--lexical-source", "nominal_assertions.txt"], 3, "DEFER")
    smoke("verify-count-phrase", ["verify-count-phrase", "read-count-phrase.json", "--source", "count_phrase.txt", "--lexical-source", "nominal_assertions.txt"], 0, "VERIFIED", True)
    smoke("withdraw-counted-lexical-source", ["verify-count-phrase", "read-count-phrase.json", "--source", "count_phrase.txt"], 2, "REJECT", False)
    smoke("number-rule-outside-domain", ["number-rule", "101", "masculine"], 3, "DEFER", stderr_json=True)
    encoded = smoke("read-nominal-with-number", ["read-nominal", "nominal.txt", "--lexical-source", "nominal_assertions.txt", "--with-number"], 3)
    require(encoded["report"] == report and encoded["encoding"]["authority"] == "ENCODING_ONLY", "Reversible output mismatch")
    replay_code = r'''
import json, pathlib
from nabt.nominal import decode_nominal
payload = json.loads(pathlib.Path("read-nominal-with-number.json").read_text())
restored = decode_nominal(int(payload["encoding"]["number_hex"], 16))
assert restored == payload["report"]
print(json.dumps({"valid": True, "status": "EXACT_ROUNDTRIP", "authority": payload["encoding"]["authority"]}))
'''
    roundtrip = json.loads(run("decode-nominal-number", [python, "-I", "-c", replay_code]).stdout)
    require(roundtrip["valid"] is True, "Installed nominal encoding roundtrip mismatch")
    write_json(OUT / "results/decode-nominal-number.json", roundtrip)
    verify_source()
    require(freeze_path.read_bytes() == freeze_bytes, "Freeze changed")
    validation = {
        "schema": "nabt.nominal.wheel-validation.v1", "ok": True,
        "utc": datetime.now(timezone.utc).isoformat(), "version": EXPECTED_VERSION,
        "freeze": {"path": "evidence/nominal/code_freeze_v1.json", "sha256": digest(freeze_path.read_bytes()),
                   "snapshot_sha256": EXPECTED_SNAPSHOT, "archive_sha256": freeze["archive_sha256"],
                   "baseline_head": freeze["repository_head"], "file_count": 52},
        "wheel": {"path": str(wheel.relative_to(OUT)), "sha256": digest(wheel.read_bytes()), "bytes": wheel.stat().st_size},
        "build_environment": {"python": sys.version, "executable": sys.executable,
                              "pip": importlib.metadata.version("pip"), "setuptools": importlib.metadata.version("setuptools"),
                              "wheel": importlib.metadata.version("wheel"), "no_build_isolation": True,
                              "no_dependencies": True, "no_index": True, "build_extras": build_extras},
        "isolation": {"temporary_root": str(work), "working_directory": str(cwd),
                      "installed_origin": installed["module_origin"], "venv": str(venv),
                      "pythonpath_removed": True, "pythonhome_removed": True, "inspection_isolated_mode": True},
        "correspondence": {"current_frozen_files_before_and_after": 52, "archive_files": 52,
                           "wheel_package_files": 51, "installed_package_files": 51,
                           "all_package_bytes_match_freeze": True, "unexpected_package_files": [],
                           "pyproject": {"installed_as_file": False, "sha256": source_rows["pyproject.toml"]["sha256"],
                                         "metadata_checked": ["Name", "Version", "Requires-Python", "Requires-Dist", "console_scripts:nabt"]},
                           "nominal_table_sha256": EXPECTED_TABLE},
        "example_sources": sources, "smoke_checks": smokes, "smoke_check_count": len(smokes),
        "cli_version_checked": True, "nominal_number_roundtrip": roundtrip,
        "scope": ["Installed-wheel correspondence and bounded CLI examples only.",
                  "Successful replay verifies source-bound report reconstruction, not linguistic or world truth.",
                  "DEFER is expected exit 3; lexical-source withdrawal is expected rejection exit 2.",
                  "The parent release task runs make check separately; no full gate or independent gold was rerun or read here."]
    }
    write_json(OUT / "validation.json", validation)
    files = []
    for path in sorted(OUT.rglob("*")):
        if path.is_file() and path.name != "manifest.json":
            data = path.read_bytes()
            files.append({"path": str(path.relative_to(OUT)), "bytes": len(data), "sha256": digest(data)})
    write_json(OUT / "manifest.json", {"schema": "nabt.nominal.packaging-artifacts.v1", "files": files})
    print(json.dumps({"ok": True, "wheel_sha256": validation["wheel"]["sha256"],
                      "files_frozen": 52, "package_files_installed": 51,
                      "smoke_checks": len(smokes), "validation": str(OUT / "validation.json")}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        write_json(OUT / "failure.json", {"ok": False, "type": type(error).__name__, "message": str(error)})
        raise
