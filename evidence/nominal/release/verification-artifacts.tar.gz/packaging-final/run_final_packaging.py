"""Rebuild documentation metadata; retain and reference the original 15 smokes."""

from __future__ import annotations

from datetime import datetime, timezone
from email.parser import BytesParser
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import subprocess
import sys
import tarfile
import tempfile
import tomllib
from zipfile import ZipFile


OUT = Path(__file__).resolve().parent
REPO = Path(__file__).resolve().parents[4]
PRIOR = OUT.with_name("packaging")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def require(value, message):
    if not value:
        raise AssertionError(message)


def write_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def main():
    prior_validation_raw = (PRIOR / "validation.json").read_bytes()
    prior_manifest_raw = (PRIOR / "manifest.json").read_bytes()
    prior = json.loads(prior_validation_raw)
    prior_manifest = json.loads(prior_manifest_raw)
    require(prior["ok"] and prior["smoke_check_count"] == 15, "Prior smoke record is not successful")
    require(sha(prior_validation_raw) == "ac6cbecf099885f2e09e0f55f65fb0edf47497b32fd9baf488a7fd51c737a675", "Prior validation differs")

    def verify_prior():
        require((PRIOR / "validation.json").read_bytes() == prior_validation_raw, "Prior validation changed")
        require((PRIOR / "manifest.json").read_bytes() == prior_manifest_raw, "Prior manifest changed")
        for row in prior_manifest["files"]:
            data = (PRIOR / row["path"]).read_bytes()
            require(len(data) == row["bytes"] and sha(data) == row["sha256"], "Prior artifact changed: " + row["path"])

    verify_prior()
    freeze_path = REPO / "evidence/nominal/code_freeze_v1.json"
    freeze_raw = freeze_path.read_bytes()
    freeze = json.loads(freeze_raw)
    source_rows = {r["path"]: r for r in freeze["files"]}
    package_rows = {p.removeprefix("src/"): r for p, r in source_rows.items() if p.startswith("src/")}
    require(len(source_rows) == 52 and len(package_rows) == 51, "Unexpected runtime inventory")
    require(freeze["snapshot_sha256"] == prior["freeze"]["snapshot_sha256"], "Runtime snapshot changed")
    require(sha(json.dumps(freeze["files"], sort_keys=True, separators=(",", ":")).encode()) == freeze["snapshot_sha256"],
            "Invalid snapshot digest")

    def verify_source():
        require(freeze_path.read_bytes() == freeze_raw, "Runtime freeze changed")
        for path, row in source_rows.items():
            data = (REPO / path).read_bytes()
            require(len(data) == row["bytes"] and sha(data) == row["sha256"], "Runtime file changed: " + path)

    verify_source()
    archive_path = freeze_path.with_name(freeze["archive_filename"])
    require(sha(archive_path.read_bytes()) == freeze["archive_sha256"], "Runtime archive changed")
    work = Path(tempfile.mkdtemp(prefix="nabt-nominal-packaging-final-"))
    stage, cwd, venv = work / "frozen-source", work / "smoke", work / "venv"
    stage.mkdir()
    cwd.mkdir()
    for name in ("logs", "wheel", "inputs"):
        (OUT / name).mkdir(exist_ok=True)
    with tarfile.open(archive_path, "r:gz") as tf:
        members = tf.getmembers()
        require(len(members) == 52 and {m.name for m in members} == set(source_rows), "Runtime archive inventory differs")
        for member in members:
            require(member.isfile(), "Runtime archive contains non-file")
            data = tf.extractfile(member).read()
            row = source_rows[member.name]
            require(len(data) == row["bytes"] and sha(data) == row["sha256"], "Runtime archive member differs")
            target = stage / member.name
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
    build_extras = []
    for name in ("README.md", "LICENSE"):
        data = (REPO / name).read_bytes()
        (stage / name).write_bytes(data)
        (OUT / "inputs" / name).write_bytes(data)
        build_extras.append({"path": name, "bytes": len(data), "sha256": sha(data)})
    readme = (stage / "README.md").read_bytes()
    project = tomllib.loads((stage / "pyproject.toml").read_text())["project"]
    require(project["version"] == "0.11.0a1", "Unexpected version")
    env = dict(os.environ)
    for name in ("PYTHONPATH", "PYTHONHOME"):
        env.pop(name, None)
    env.update(PIP_CONFIG_FILE=os.devnull, PIP_DISABLE_PIP_VERSION_CHECK="1", PYTHONNOUSERSITE="1")
    commands = []

    def run(name, argv):
        result = subprocess.run([str(x) for x in argv], cwd=cwd, env=env, capture_output=True, timeout=180)
        (OUT / "logs" / (name + ".stdout")).write_bytes(result.stdout)
        (OUT / "logs" / (name + ".stderr")).write_bytes(result.stderr)
        commands.append({"name": name, "argv": [str(x) for x in argv], "cwd": str(cwd),
                         "exit_code": result.returncode, "expected_exit_code": 0,
                         "stdout": "logs/" + name + ".stdout", "stderr": "logs/" + name + ".stderr"})
        write_json(OUT / "commands.json", commands)
        require(result.returncode == 0, name + " failed; inspect saved log")
        return result

    run("build-wheel", [sys.executable, "-m", "pip", "wheel", stage,
                        "--no-build-isolation", "--no-deps", "--no-index", "--wheel-dir", OUT / "wheel"])
    wheel = OUT / "wheel/nabt_machine-0.11.0a1-py3-none-any.whl"
    require(wheel.is_file(), "Expected wheel not built")
    old_wheel = PRIOR / prior["wheel"]["path"]
    require(sha(old_wheel.read_bytes()) == prior["wheel"]["sha256"], "Prior wheel changed")
    dist = "nabt_machine-0.11.0a1.dist-info/"
    with ZipFile(old_wheel) as old, ZipFile(wheel) as new:
        require(set(old.namelist()) == set(new.namelist()), "Wheel member inventory changed")
        changes = sorted(n for n in new.namelist() if new.read(n) != old.read(n))
        require(changes == [dist + "METADATA", dist + "RECORD"], "Wheel has changes beyond documentation metadata")
        require({n for n in new.namelist() if n.startswith("nabt/")} == set(package_rows), "Wheel package inventory differs")
        for path, row in package_rows.items():
            data = new.read(path)
            require(data == old.read(path), "Package differs from previously tested wheel: " + path)
            require(len(data) == row["bytes"] and sha(data) == row["sha256"], "Package differs from frozen runtime: " + path)
        metadata_raw = new.read(dist + "METADATA")
        headers, separator, body = metadata_raw.partition(b"\n\n")
        require(bool(separator) and body == readme, "Wheel METADATA description differs from final README bytes")
        metadata = BytesParser().parsebytes(metadata_raw)
        require(metadata["Name"] == project["name"] and metadata["Version"] == project["version"], "Wheel identity differs")
        require(metadata["Requires-Python"] == project["requires-python"], "Python requirement differs")
        require(metadata.get_all("Requires-Dist", []) == project["dependencies"], "Dependencies differ")
        entrypoint_raw = new.read(dist + "entry_points.txt")
        require(b"nabt = nabt.cli:main" in entrypoint_raw, "Console entry point differs")
    run("create-venv", [sys.executable, "-m", "venv", venv])
    python, nabt = venv / "bin/python", venv / "bin/nabt"
    run("install-wheel", [python, "-m", "pip", "install", "--no-deps", "--no-index", wheel])
    inspect = r'''
import hashlib, importlib.metadata as md, json, pathlib, sys
import nabt
distribution = md.distribution("nabt-machine")
root = pathlib.Path(nabt.__file__).parent
files = []
for path in sorted(root.rglob("*")):
    if path.is_file() and "__pycache__" not in path.parts:
        raw = path.read_bytes()
        files.append({"path": "nabt/" + str(path.relative_to(root)), "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
metadata_path = next(f for f in distribution.files if str(f).endswith(".dist-info/METADATA"))
raw = distribution.locate_file(metadata_path).read_bytes()
print(json.dumps({"distribution_version": distribution.version, "module_version": nabt.__version__,
 "module_origin": nabt.__file__, "python": sys.executable, "files": files,
 "metadata_sha256": hashlib.sha256(raw).hexdigest(),
 "description_sha256": hashlib.sha256(raw.partition(b"\n\n")[2]).hexdigest(),
 "entry_points": [{"name": p.name, "value": p.value, "group": p.group} for p in distribution.entry_points]}, indent=2))
'''
    installed = json.loads(run("inspect-install", [python, "-I", "-c", inspect]).stdout)
    require(installed["distribution_version"] == "0.11.0a1" and installed["module_version"] == "0.11.0a1", "Installed version differs")
    require(Path(installed["module_origin"]).is_relative_to(venv), "Installation resolved the checkout")
    require(installed["metadata_sha256"] == sha(metadata_raw) and installed["description_sha256"] == sha(readme),
            "Installed README metadata differs")
    require(installed["entry_points"] == [{"name": "nabt", "value": "nabt.cli:main", "group": "console_scripts"}], "Installed entry point differs")
    observed = {r["path"]: r for r in installed["files"]}
    require(set(observed) == set(package_rows), "Installed package inventory differs")
    for path, row in package_rows.items():
        require(observed[path]["sha256"] == row["sha256"] and observed[path]["bytes"] == row["bytes"], "Installed file differs: " + path)
    write_json(OUT / "installed-files.json", installed)
    smoke_inputs = []
    for previous, name in (("results/read-nominal.json", "report.json"),
                           ("sources/nominal.txt", "nominal.txt"),
                           ("sources/nominal_assertions.txt", "nominal_assertions.txt")):
        data = (PRIOR / previous).read_bytes()
        (cwd / name).write_bytes(data)
        smoke_inputs.append({"prior_path": "../packaging/" + previous, "sha256": sha(data), "bytes": len(data)})
    smoke = run("verify-nominal", [nabt, "verify-nominal", "report.json", "--source", "nominal.txt",
                                   "--lexical-source", "nominal_assertions.txt"])
    result = json.loads(smoke.stdout)
    require(result["valid"] is True and result["status"] == "VERIFIED" and smoke.stderr == b"", "One-smoke replay failed")
    write_json(OUT / "smoke.json", result)
    verify_source()
    verify_prior()
    require((REPO / "README.md").read_bytes() == readme, "Final README changed during build")
    validation = {
        "schema": "nabt.nominal.documentation-wheel-rebuild.v1", "ok": True,
        "utc": datetime.now(timezone.utc).isoformat(), "version": project["version"],
        "reason": "README updated after original packaging to include final 576 tests / 520 theorems / 184 independent cases; runtime unchanged.",
        "freeze": {"path": "evidence/nominal/code_freeze_v1.json", "sha256": sha(freeze_raw),
                   "snapshot_sha256": freeze["snapshot_sha256"], "source_files": 52},
        "wheel": {"path": str(wheel.relative_to(OUT)), "sha256": sha(wheel.read_bytes()), "bytes": wheel.stat().st_size},
        "prior_validation": {"path": "../packaging/validation.json", "sha256": sha(prior_validation_raw),
                             "wheel_sha256": prior["wheel"]["sha256"], "smoke_check_count": 15,
                             "cli_version_checked": True, "nominal_number_roundtrip_checked": True,
                             "manifest_path": "../packaging/manifest.json", "manifest_sha256": sha(prior_manifest_raw),
                             "preserved_artifact_count": len(prior_manifest["files"]), "all_prior_hashes_unchanged": True},
        "correspondence": {"frozen_files_checked_before_and_after": 52, "package_files_equal_previous_wheel": 51,
                           "package_files_equal_freeze": 51, "installed_package_files_equal_freeze": 51,
                           "wheel_members_with_changed_bytes": changes, "runtime_change": False,
                           "readme_bytes": len(readme), "readme_sha256": sha(readme),
                           "wheel_metadata_description_exactly_matches_readme": True,
                           "installed_metadata_description_exactly_matches_readme": True,
                           "metadata_sha256": sha(metadata_raw), "entrypoint_sha256": sha(entrypoint_raw),
                           "nominal_table_sha256": observed["nabt/data/nominal_evidence.json"]["sha256"]},
        "build": {"python": sys.version, "pip": importlib.metadata.version("pip"),
                  "setuptools": importlib.metadata.version("setuptools"), "wheel": importlib.metadata.version("wheel"),
                  "no_build_isolation": True, "no_dependencies": True, "no_index": True,
                  "documentation_inputs": build_extras},
        "isolation": {"temporary_root": str(work), "working_directory": str(cwd),
                      "installed_origin": installed["module_origin"], "pythonpath_removed": True, "pythonhome_removed": True},
        "smoke_count": 1, "smoke": {"command": "verify-nominal", "exit_code": 0,
                                   "status": result["status"], "valid": result["valid"], "inputs": smoke_inputs},
        "scope": "Documentation-only rebuild. The prior 15 CLI checks remain evidence for byte-identical runtime files; they were not rerun. One installed replay passed. Full-gate results are recorded separately."
    }
    write_json(OUT / "validation.json", validation)
    (OUT / "README.md").write_text(
        "# Final nominal wheel: documentation-only rebuild\n\n"
        "The project README was updated after the original packaging run to record "
        "the completed release gates. This wheel includes that final README verbatim "
        "in both wheel and installed METADATA.\n\n"
        "All 51 package files match the frozen runtime and the previously tested wheel "
        "byte for byte. Only METADATA and its RECORD digest changed among wheel member "
        "contents. Version and console entry point remain 0.11.0a1 and nabt.cli:main.\n\n"
        "The original packaging directory is preserved and referenced by exact hashes "
        "in validation.json: its 15 CLI cases, CLI version check and numeric roundtrip "
        "were not repeated. One fresh installed verify-nominal replay returned VERIFIED, "
        "valid true, exit 0.\n\n"
        "validation.json records all comparisons and pins; commands.json and logs/ "
        "record the actual build/install/inspection/smoke invocations. inputs/ preserves "
        "the final README and license used. installed-files.json records the 51 "
        "installed package hashes. wheel/ contains the final distribution.\n\n"
        "No runtime, test, CI, tool, freeze, gold or repository documentation file "
        "was changed by this rebuild. This is packaging correspondence evidence; "
        "full gates and linguistic limitations retain their separate records.\n",
        encoding="utf-8")
    manifest = []
    for path in sorted(OUT.rglob("*")):
        if path.is_file() and path.name != "manifest.json":
            data = path.read_bytes()
            manifest.append({"path": str(path.relative_to(OUT)), "bytes": len(data), "sha256": sha(data)})
    write_json(OUT / "manifest.json", {"schema": "nabt.nominal.packaging-final-artifacts.v1", "files": manifest})
    print(json.dumps({"ok": True, "version": project["version"], "wheel_sha256": validation["wheel"]["sha256"],
                      "readme_sha256": sha(readme), "package_files": 51, "smokes_run": 1,
                      "prior_smokes_referenced": 15, "validation": str(OUT / "validation.json")}, indent=2))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        write_json(OUT / "failure.json", {"ok": False, "type": type(error).__name__, "message": str(error)})
        raise
