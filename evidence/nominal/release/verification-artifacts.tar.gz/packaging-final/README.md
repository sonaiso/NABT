# Final nominal wheel: documentation-only rebuild

The project README was updated after the original packaging run to record the completed release gates. This wheel includes that final README verbatim in both wheel and installed METADATA.

All 51 package files match the frozen runtime and the previously tested wheel byte for byte. Only METADATA and its RECORD digest changed among wheel member contents. Version and console entry point remain 0.11.0a1 and nabt.cli:main.

The original packaging directory is preserved and referenced by exact hashes in validation.json: its 15 CLI cases, CLI version check and numeric roundtrip were not repeated. One fresh installed verify-nominal replay returned VERIFIED, valid true, exit 0.

validation.json records all comparisons and pins; commands.json and logs/ record the actual build/install/inspection/smoke invocations. inputs/ preserves the final README and license used. installed-files.json records the 51 installed package hashes. wheel/ contains the final distribution.

No runtime, test, CI, tool, freeze, gold or repository documentation file was changed by this rebuild. This is packaging correspondence evidence; full gates and linguistic limitations retain their separate records.
