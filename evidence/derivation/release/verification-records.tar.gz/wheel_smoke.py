"""Installed-wheel verification, launched from /tmp without source imports."""
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
import subprocess
import sys
import tempfile

import nabt
from nabt.derivation import (read_derivation, verify_derivation, generate_derivation,
                             derivation_number, decode_derivation, installed_registry)
from nabt.verb_paradigm import read_verb_paradigm, verify_verb_paradigm

DESTINATION = Path("/workspace/scratch/93a907621097/NABT/artifacts/local/derivation-final")
INSTALLED = Path("/tmp/nabt-derivation-wheel-check")
assert Path(nabt.__file__).resolve().is_relative_to(INSTALLED)
assert nabt.__version__ == "0.10.0a1"
checks = []

def checked(name, condition):
    assert condition, name
    checks.append(name)

table = installed_registry()
checked("installed_generated_registry", len(table["patterns"]) == 71 and len(table["paradigm_rows"]) == 64)
text = "كَاتِبٌ مِفْتَاحٌ عُصَيْفِيرٌ انْتَبَر\nسَوْفَ يَكْتُبُ"
reading = read_derivation(text, scope="installed")
checked("external_source_replay", verify_derivation(reading, text=text, source_id="input", scope="installed")["valid"])
checked("reversible_report_number", decode_derivation(derivation_number(reading)) == reading)
checked("no_class_or_case_promotion", all(not c["lexical_class_activated"] and c["actual_case"] is None
    for r in reading["occurrences"] for c in r["candidates"]))
collision = {(c["pattern_id"], c["root"]) for c in reading["occurrences"][3]["candidates"]}
checked("cross_pattern_roots_preserved", {("past.VII", "تبر"), ("past.VIII", "نبر")} <= collision)
checked("new_instrument_projection", generate_derivation("فتح", "grammar.instrument.mif3aal", ending="ٌ")["surface"] == "مِفْتَاحٌ")
changed = deepcopy(reading)
changed["occurrences"][0]["actual_case"] = "raf"
checked("forged_case_rejected", not verify_derivation(changed)["valid"])
paradigm_text = "الفعل «ليس».\nالماضي مستعمل: «لَيْسَ».\nالمضارع غير مستعمل.\nالأمر غير مستعمل."
paradigm = read_verb_paradigm(paradigm_text)
checked("conditional_paradigm_axis", paradigm["readings"][0]["axis"]["candidates"] == ["jamid"])
checked("paradigm_external_replay", verify_verb_paradigm(paradigm, text=paradigm_text)["valid"])

with tempfile.TemporaryDirectory(prefix="nabt-derivation-cli-") as directory:
    source = Path(directory) / "source.txt"
    report_path = Path(directory) / "report.json"
    source.write_text(text, encoding="utf-8")
    process = subprocess.run([sys.executable, "-m", "nabt", "read-derivation", str(source)],
                             capture_output=True, text=True, check=False)
    checked("cli_read_exit_is_defer", process.returncode == 3)
    report_path.write_text(process.stdout, encoding="utf-8")
    process = subprocess.run([sys.executable, "-m", "nabt", "verify-derivation", str(report_path),
                              "--source", str(source)], capture_output=True, text=True)
    checked("cli_external_verify", process.returncode == 0 and json.loads(process.stdout)["valid"])
    process = subprocess.run([sys.executable, "-m", "nabt", "derivation-catalog"], capture_output=True, text=True)
    checked("cli_catalog", process.returncode == 0 and len(json.loads(process.stdout)["patterns"]) == 71)
    source.write_text(paradigm_text, encoding="utf-8")
    process = subprocess.run([sys.executable, "-m", "nabt", "read-verb-paradigm", str(source)],
                             capture_output=True, text=True)
    checked("cli_paradigm", process.returncode == 0 and json.loads(process.stdout)["status"] == "READ")
    report_path.write_text(process.stdout, encoding="utf-8")
    process = subprocess.run([sys.executable, "-m", "nabt", "verify-verb-paradigm", str(report_path),
                              "--source", str(source)], capture_output=True, text=True)
    checked("cli_paradigm_verify", process.returncode == 0 and json.loads(process.stdout)["valid"])

wheel = DESTINATION / "wheel/nabt_machine-0.10.0a1-py3-none-any.whl"
result = {"ok": True, "package_version": nabt.__version__, "module_origin": nabt.__file__,
          "cwd": str(Path.cwd()), "python_version": sys.version, "checks": checks,
          "wheel_sha256": sha256(wheel.read_bytes()).hexdigest(), "wheel_bytes": wheel.stat().st_size,
          "source_tree_imported": False,
          "scope": "Installed package APIs, CLI, packaged law, exact replay, ambiguity and authority boundaries"}
with (DESTINATION / "wheel-smoke.json").open("x", encoding="utf-8") as handle:
    json.dump(result, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
with (DESTINATION / "wheel-example-report.json").open("x", encoding="utf-8") as handle:
    json.dump(reading, handle, ensure_ascii=False, indent=2)
    handle.write("\n")
print(json.dumps(result, indent=2))
