"""Bind observed validation records to the committed source and runtime freeze."""
from datetime import datetime, timezone
from hashlib import sha256
import json
from pathlib import Path
import platform
import re
import subprocess
import sys
import tarfile

ROOT = Path("/workspace/scratch/93a907621097/NABT")
BASE = ROOT / "artifacts/local/derivation-final"
DEST = ROOT / "evidence/derivation/release"
DEST.mkdir(exist_ok=False)
sys.path.insert(0, str(ROOT / "tools"))
from text_evaluation.integrity import authoritative_paths, verify_code_freeze

def digest(data):
    return sha256(data).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding="utf-8"))

def write(path, value):
    with path.open("x", encoding="utf-8") as handle:
        handle.write(json.dumps(value, ensure_ascii=False, indent=2) + "\n")

def record(path):
    return {"path": str(path.relative_to(ROOT)), "bytes": path.stat().st_size,
            "sha256": digest(path.read_bytes())}

def archived(path):
    return {"archive_member": str(path.relative_to(BASE)), "bytes": path.stat().st_size,
            "sha256": digest(path.read_bytes())}

implementation = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
freeze_path = ROOT / "evidence/derivation/code_freeze_v1.json"
freeze = verify_code_freeze(freeze_path, root=ROOT)
runtime_archive = freeze_path.parent / freeze["archive_filename"]
assert digest(runtime_archive.read_bytes()) == freeze["archive_sha256"]
with tarfile.open(runtime_archive, "r:gz") as archive:
    assert {m.name for m in archive.getmembers()} == {r["path"] for r in freeze["files"]}
    for item in freeze["files"]:
        raw = archive.extractfile(item["path"]).read()
        assert len(raw) == item["bytes"] and digest(raw) == item["sha256"]

tracked = subprocess.check_output(["git", "ls-files"], cwd=ROOT, text=True).splitlines()
verification_names = sorted(p for p in tracked if
    p == "Makefile" or p.startswith(("formal/", "tests/", "tools/"))
    or p.startswith("evidence/derivation/") and p.endswith((".json", ".md")))
source_rows = [record(ROOT / p) for p in verification_names]
for name in sorted(set(verification_names) | authoritative_paths(ROOT)):
    committed = subprocess.check_output(["git", "show", implementation + ":" + name], cwd=ROOT)
    assert committed == (ROOT / name).read_bytes(), name
source_manifest_path = DEST / "verification-source-manifest.json"
write(source_manifest_path, {"schema": "nabt.derivation.verification-sources.v1",
    "implementation_commit": implementation,
    "scope": "Formal sources, evaluators, tests, Makefile and derivation source/evidence manifests; runtime has its separate complete freeze.",
    "files": source_rows})

records = sorted(p for p in (BASE / "verified").rglob("*") if p.is_file())
records += [BASE / name for name in ("make-check.log", "wheel-build.log", "wheel-install.log",
    "wheel-smoke.json", "wheel-example-report.json", "wheel_smoke.py", "build_release_record.py")]
records = sorted(set(records))
archive_path = DEST / "verification-records.tar.gz"
with tarfile.open(archive_path, "x:gz") as archive:
    for path in records:
        archive.add(path, arcname=str(path.relative_to(BASE)), recursive=False)
record_rows = [archived(p) for p in records]
records_manifest_path = DEST / "verification-records-manifest.json"
write(records_manifest_path, {"schema": "nabt.derivation.verification-records.v1",
    "archive": record(archive_path), "files": record_rows})
with tarfile.open(archive_path, "r:gz") as archive:
    assert {m.name for m in archive.getmembers()} == {r["archive_member"] for r in record_rows}
    for item in record_rows:
        data = archive.extractfile(item["archive_member"]).read()
        assert digest(data) == item["sha256"] and len(data) == item["bytes"]

log = (BASE / "make-check.log").read_text()
test_count, test_seconds = re.search(r"Ran (\d+) tests in ([0-9.]+)s\s+OK", log).groups()
assert int(test_count) == 523 and "python3 tools/check_integrity.py" in log
audit = read(BASE / "verified/axioms.json")
conformance = read(BASE / "verified/derivation-conformance.json")
independent = read(BASE / "verified/derivation-regression.json")
text_morphology = read(BASE / "verified/text-morphology-regression.json")
morphology = read(BASE / "verified/morphology-regression.json")
words = read(BASE / "verified/word-regression.json")
governors = read(BASE / "verified/governor-regression/summary.json")
arabic = read(BASE / "verified/arabic-regression/receipt.json")
wheel = read(BASE / "wheel-smoke.json")
assert audit["ok"] and audit["theorem_count"] == 476
assert conformance["ok"] and conformance["patterns"] == 71
assert independent["passed"] and text_morphology["passed"] and wheel["ok"]

validation = {
    "schema": "nabt.derivation.release-validation.v1",
    "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
    "package_version": "0.10.0a1", "status": "BOUNDED_VALIDATION_PASS",
    "repository_base_commit": "07d2be22192c8d083d27f0069da10168b9445578",
    "previous_local_implementation_head": "7cdf364573d376b82fdfe55ca9e5e1161a1567a0",
    "implementation_commit": implementation, "release_commit": None,
    "release_commit_note": "The following evidence-only commit contains this record; source and runtime identities are pinned without a recursive commit hash.",
    "implementation_commit_matches_runtime_and_verification_sources": True,
    "committed_source_files_checked": len(set(verification_names) | authoritative_paths(ROOT)),
    "runtime": {"freeze_version": "derivation_v1", "manifest": record(freeze_path),
        "snapshot_sha256": freeze["snapshot_sha256"], "file_count": len(freeze["files"]),
        "archive": record(runtime_archive), "current_bytes_match_frozen_inventory": True,
        "inventory_is_exact_authoritative_runtime": True, "archive_members_match_frozen_inventory": True},
    "verification_sources": {**record(source_manifest_path), "file_count": len(source_rows)},
    "full_check": {"outcome": "PASS", "runner_observed_exit_code": 0,
        "tests_run": int(test_count), "failures": 0, "test_seconds": float(test_seconds),
        "reproduction_command": "make check LAKE=/absolute/path/to/lake EVIDENCE_DIR=artifacts/local/derivation-reproduction/verified ARABIC_EVALUATION_DIR=artifacts/local/derivation-reproduction/verified/arabic-regression",
        "lean_toolchain": (ROOT / "formal/lean-toolchain").read_text().strip(),
        "log": archived(BASE / "make-check.log"), "last_integrity_gate_passed": True,
        "runtime_environment": {"python": sys.version, "platform": platform.platform()}},
    "formal_audit": {"report": archived(BASE / "verified/axioms.json"),
        "raw_log": archived(BASE / "verified/axioms.log"), "theorem_count": audit["theorem_count"],
        "new_theorems": 55, "new_theorem_groups": {"general_and_core_patterns": 26, "conditional_verb_availability": 17, "nominal_supplement": 12},
        "observed_axioms": audit["observed_axioms"], "project_axioms_allowed": False,
        "all_nabt_declarations_scanned": audit["all_nabt_declarations_scanned"]},
    "derivation_conformance": {"report": archived(BASE / "verified/derivation-conformance.json"), **conformance},
    "independent_evaluation": {"report": archived(BASE / "verified/derivation-regression.json"),
        "raw_score": independent["raw_score"], "task_scores": independent["task_scores"],
        "passed": independent["passed"], "material_sha256": independent["material_sha256"],
        "claim_limits": independent["claim_limits"],
        "history": {"first_run": record(ROOT / "evidence/derivation/independent_first_run_v1.json"),
            "adapter_erratum": record(ROOT / "evidence/derivation/adapter_erratum_v1.json"),
            "second_run": record(ROOT / "evidence/derivation/independent_second_run_v1.json"),
            "first_raw_score": "6/96; invalid morphology measurement because the adapter used invalid source IDs",
            "gold_text_or_expected_answers_changed": False,
            "pre_first_run_quotation_correction": record(ROOT / "evidence/derivation/pre_first_run_review_v1.json")}},
    "old_regressions": {
        "text_morphology": {"report": archived(BASE / "verified/text-morphology-regression.json"), "raw_score": text_morphology["raw_score"], "passed": text_morphology["passed"]},
        "morphology": {"report": archived(BASE / "verified/morphology-regression.json"), "summary": morphology["summary"]},
        "words": {"report": archived(BASE / "verified/word-regression.json"), "summary": words["summary"]},
        "governors": {"report": archived(BASE / "verified/governor-regression/summary.json"), "summary": governors},
        "arabic_syntax": {"report": archived(BASE / "verified/arabic-regression/receipt.json"), "receipt": arabic}},
    "wheel": {"report": archived(BASE / "wheel-smoke.json"), **wheel},
    "verification_records": {"archive": record(archive_path), "manifest": record(records_manifest_path), "file_count": len(records)},
    "source_provenance": {"repositories_reviewed": 9, "upstream_rebuilt": False,
        "source_audits": [record(ROOT / ("evidence/derivation/source_audit_" + name + ".json")) for name in ("mashru", "alghanem", "other")],
        "coverage": record(ROOT / "evidence/derivation/requested_category_coverage.json"),
        "nominal_projection_sources": record(ROOT / "evidence/derivation/nominal_pattern_sources.json")},
    "publication": {"status": "NOT_PUBLISHED", "branch": "feat/derivation-pattern-evidence",
        "reason": "No usable GitHub credential is present; the connected installation's selected repositories do not include NABT. User authorization is already granted.",
        "merge_performed": False},
    "limits": ["Shape candidates are not attested lexical roots, word kinds, semantic classes, syntactic roles or case.",
        "The 96-case material has positive pre-implementation coverage of44 core patterns; the27 later nominal patterns have separate authored examples, formal contracts and conformance evidence.",
        "Verb availability classification is conditional on explicit same-lexeme source assertions; missing corpus forms are not negative evidence.",
        "The finite profiles do not include general weak/hamza realization, clitic/nun attachment, augmented participles, passive imperfect, complete quadriliteral conjugation, or recovery of the pre-diminutive word.",
        "Python Unicode parsing, source-span construction and linguistic premise truth have not received a complete Lean refinement proof.",
        "Previous broad Arabic/governor coverage limits remain unchanged; passing regression gates is not full coverage."]
}
write(DEST / "validation.json", validation)
print(json.dumps({"implementation_commit": implementation, "validation": record(DEST / "validation.json"),
    "records": len(records), "verification_sources": len(source_rows), "runtime_files": len(freeze["files"]),
    "archive": record(archive_path)}, indent=2))
