"""Loss-preserving occurrence ancestry from the frozen 116/84 inventory.

No Unicode ordinal, hash, dictionary ID or inferred meaning is an A116 unit.
Text and offsets are metadata; each phonological unit cites the exact inherited
carrier/state witness.  A selected reading is an input, not a disambiguation
achievement.  A document closes the connected-boundary obligations of its
occurrences.  Lexical/sense/reference/evidence gates belong to the same V13
integrated contract, implemented by the other modules.
"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
from functools import lru_cache
from pathlib import Path
import hashlib
import json
import re
import unicodedata

ROOT = Path(__file__).resolve().parent
RULES_PATH = ROOT / "a116_rules_v13.json"
BASIS_PATH = ROOT / "v12/inherited/atomic_ancestry_catalog_v10.json"
FATHA, DAMMA, KASRA, SUKUN, SHADDA = "َ", "ُ", "ِ", "ْ", "ّ"
FATHATAN, DAMMATAN, KASRATAN, DAGGER = "ً", "ٌ", "ٍ", "ٰ"
STATES = {FATHA:"a", DAMMA:"u", KASRA:"i", SUKUN:"S",
          FATHATAN:"a", DAMMATAN:"u", KASRATAN:"i"}
TANWIN = {FATHATAN, DAMMATAN, KASRATAN}
SUPPORTED_MARKS = set(STATES) | {SHADDA, DAGGER}
SEATED = {"أ":"ء", "إ":"ء", "ؤ":"ء", "ئ":"ء"}
CARRIERS = "اب ت ث ج ح خ د ذ ر ز س ش ص ض ط ظ ع غ ف ق ك ل م ن ه و ي ء".replace(" ", "")
INDEX = {c:i for i,c in enumerate(CARRIERS)}
SOLAR = set("تثدذرزسشصضطظلن")
BOUNDS = {"IBTIDA", "WASL", "FASL", "WAQF"}
TOKEN_RE = re.compile(r"[\w\u064b-\u065f\u0670\u06d6-\u06ed]+|[^\w\s]", re.UNICODE)
STRUCTURAL = set(".،,؛;:!?؟«»\"“”‘’()[]{}—–-…/\\|+=*<>٪%")
PAUSES = set(".،,؛;:!?؟…")


def _canon(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


@lru_cache(maxsize=1)
def basis():
    rules = json.loads(RULES_PATH.read_text(encoding="utf-8"))
    raw = BASIS_PATH.read_bytes()
    sha = hashlib.sha256(raw).hexdigest()
    if sha != rules["basis_sha256"]:
        raise ValueError("Frozen 116/84 basis fingerprint differs")
    data = json.loads(raw)
    if data["source116_count"] != 116 or data["derived84_count"] != 84:
        raise ValueError("Frozen counts differ")
    rows = {r["type_id"]:r for r in data["slot_witnesses"]}
    if set(rows) != set(range(4, 200)):
        raise ValueError("Frozen ordinary 112+84 output inventory differs")
    source = {r["type_id"]:r for r in data["source116_rows"]}
    for r in rows.values():
        ids = r["source116_parent_ids"]
        if r["source116_parent_origin_decimals"] != [source[x]["origin_decimal"] for x in ids]:
            raise ValueError("Inherited source origin mismatch")
    return {"data":data, "rows":rows, "sources":source, "rules":rules, "sha":sha}


def u16len(text):
    return len(text.encode("utf-16-le")) // 2


def tokenize(text):
    """Same public token indices as the V13 language compiler; space is separate."""
    result = []
    for i, m in enumerate(TOKEN_RE.finditer(text)):
        result.append({"index":i, "id":f"o{i}", "surface":m.group(),
                       "span":{"cp_start":m.start(), "cp_end":m.end(),
                               "utf16_start":u16len(text[:m.start()]),
                               "utf16_end":u16len(text[:m.end()])}})
    return result


def _clusters(text):
    out = []
    for pos, ch in enumerate(text):
        if unicodedata.combining(ch) and out:
            out[-1]["marks"].append(ch)
            out[-1]["end"] = pos+1
        else:
            out.append({"base":ch, "marks":[], "start":pos, "end":pos+1})
    for i, row in enumerate(out):
        row["index"] = i
        row["text"] = text[row["start"]:row["end"]]
    return out


def _span(surface, given):
    default = {"cp_start":0, "cp_end":len(surface), "utf16_start":0, "utf16_end":u16len(surface)}
    if given is None:
        return default
    if isinstance(given, (list, tuple)) and len(given) == 2:
        default.update(cp_start=int(given[0]), cp_end=int(given[1]))
        return default
    if not isinstance(given, dict):
        raise TypeError("span must be a mapping")
    # Exact names form the public contract; aliases are accepted and preserved
    # in inputs, not silently used as source identity.
    default.update(given)
    return default


def _reading(surface, selected):
    if selected is None:
        return {"text":surface, "mode":"RAW_SURFACE", "source_id":None}
    if isinstance(selected, str):
        return {"text":selected, "mode":"EXPLICIT_DECLARED_READING", "source_id":"CALLER_DECLARATION"}
    if not isinstance(selected, dict) or not isinstance(selected.get("text"), str):
        raise TypeError("reading must be None, a string, or a mapping with text")
    value = deepcopy(selected)
    if "mode" in value:
        value["supplier_mode"] = value["mode"]
    # Assistance is measured from the actual call, never a supplier's label.
    value["mode"] = "EXPLICIT_DECLARED_READING"
    value.setdefault("source_id", "CALLER_DECLARATION")
    return value


def _unit(carrier, state, owners, reason, occurrence_id):
    if carrier not in INDEX or INDEX[carrier] == 0:
        raise ValueError("Alif is dependent support, never an ordinary onset")
    ci = INDEX[carrier]
    tid = 4*ci + "auiS".index(state) if state in ("a", "u", "i", "S") else 116+3*(ci-1)+("aa", "uu", "ii").index(state)
    w = basis()["rows"][tid]
    return {"type_id":tid, "carrier":carrier, "carrier_index":ci, "state":state,
            "source_origin_decimal":w["source_origin_decimal"],
            "source_build_value":w["source_build_value"],
            "source116_parent_ids":list(w["source116_parent_ids"]),
            "source116_parent_origin_decimals":list(w["source116_parent_origin_decimals"]),
            "ordinary_C_slot_count":1, "support_is_extra_C":False,
            "reading_cluster_owners":list(owners), "reason":reason,
            "occurrence_id":occurrence_id}


def _renumber(units, prefix):
    for i, unit in enumerate(units):
        unit["position"] = i
        unit["id"] = f"{prefix}:u{i}"
    return units


def _op(ops, name, clusters, **details):
    numbers = {r["id"]:r["number"] for r in basis()["rules"]["rules"]}
    if name not in numbers:
        raise ValueError("Unregistered operation")
    parent_ids = []
    for key in ("citation_parent", "underlying_lam_source116", "dependent_parent", "hamza_parent", "alif_parent", "nun_source116"):
        if key in details:
            parent_ids.append(details[key])
    for key in ("input_type_id", "output_type_id"):
        if key in details and details[key] in basis()["rows"]:
            parent_ids.extend(basis()["rows"][details[key]]["source116_parent_ids"])
    parent_ids = list(dict.fromkeys(parent_ids))
    row = {"id":f"op{len(ops)}", "rule_id":name, "rule_number":numbers[name],
           "reading_cluster_indices":list(clusters), "details":details}
    row["source116_parent_ids"] = parent_ids
    row["source116_parent_origin_decimals"] = [basis()["sources"][p]["origin_decimal"] for p in parent_ids]
    ops.append(row)
    return row["id"]


def _problem(code, message, severity="DEFER", clusters=None, **fields):
    value = {"code":code, "status":severity, "message":message}
    if clusters is not None:
        value["reading_cluster_indices"] = list(clusters)
    value.update(fields)
    return value


def _status(problems):
    if any(p.get("status") == "BLOCK" for p in problems):
        return "BLOCK"
    return "DEFER" if problems else "PASS"


def _syllabify(units, *, allow_initial_pending=False, partial=False):
    syllables, problems = [], []
    start = 0
    if units and units[0]["state"] == "S":
        while start < len(units) and units[start]["state"] == "S":
            start += 1
        problems.append(_problem("WASL_PREDECESSOR_REQUIRED" if allow_initial_pending else "INITIAL_SUKUN",
                                 "Initial still consonant requires a preceding connected nucleus" if allow_initial_pending else "A new phonological segment cannot start with a still consonant",
                                 "DEFER" if allow_initial_pending or partial else "BLOCK",
                                 unit_ids=[x["id"] for x in units[:start]]))
    i = start
    while i < len(units):
        if units[i]["state"] == "S":
            problems.append(_problem("NO_NUCLEUS", "A still consonant has no licensed nucleus", "DEFER" if partial else "BLOCK"))
            i += 1
            continue
        j = i+1
        while j < len(units) and units[j]["state"] == "S":
            j += 1
        coda = j-i-1
        if coda > 2:
            problems.append(_problem("CODA_OVERFLOW", "More than two still consonants require an additional licensed operation", "DEFER" if partial else "BLOCK", unit_ids=[x["id"] for x in units[i:j]]))
        shape = "C" + ("VV" if units[i]["state"] in ("aa", "uu", "ii") else "V") + "C"*coda
        syllables.append({"shape":shape, "unit_ids":[x["id"] for x in units[i:j]],
                          "occurrence_ids":list(dict.fromkeys(x["occurrence_id"] for x in units[i:j])),
                          "cross_occurrence":len(set(x["occurrence_id"] for x in units[i:j])) > 1,
                          "status":"DEFER" if partial else ("PASS" if coda <= 2 else "BLOCK")})
        # A long closed syllable with two codas is admitted only at segment end.
        if coda == 2 and j != len(units):
            problems.append(_problem("INTERNAL_TWO_C_CODA", "Two-coda syllable inside connected speech needs a further licensed reading", "DEFER", unit_ids=[x["id"] for x in units[i:j]]))
        i = j
    return syllables, problems


def compile_occurrence(surface, reading=None, *, occurrence_id="o1", span=None,
                       boundary_before="IBTIDA", boundary_after="WAQF", role=None):
    if not isinstance(surface, str):
        raise TypeError("surface must be a string")
    frozen = basis()
    selected = _reading(surface, reading)
    text = selected["text"]
    roles = deepcopy(role) if isinstance(role, dict) else ({"declared_role":role} if role is not None else {})
    sp = _span(surface, span)
    inputs = {"surface":surface, "reading":deepcopy(reading), "occurrence_id":occurrence_id,
              "span":deepcopy(span), "boundary_before":boundary_before,
              "boundary_after":boundary_after, "role":deepcopy(role)}
    problems, operations, units = [], [], []
    source_clusters, reading_clusters = _clusters(surface), _clusters(text)
    compatibility = []
    if boundary_before not in {"IBTIDA", "WASL", "FASL"} or boundary_after not in {"WASL", "WAQF", "FASL"}:
        problems.append(_problem("INVALID_BOUNDARY", "Unregistered boundary direction", "BLOCK"))
    if sp["cp_end"] - sp["cp_start"] != len(surface) or sp["utf16_end"] - sp["utf16_start"] != u16len(surface):
        problems.append(_problem("SPAN_LENGTH_MISMATCH", "Declared source span is not the exact input extent", "BLOCK"))
    if len(source_clusters) != len(reading_clusters):
        problems.append(_problem("READING_BASE_COUNT_MISMATCH", "Selected reading must preserve every base character", "BLOCK"))
    else:
        for s, r in zip(source_clusters, reading_clusters):
            # Combining-order variation is allowed, but explicit marks never vanish.
            base_ok = s["base"] == r["base"]
            marks_ok = not (Counter(s["marks"]) - Counter(r["marks"]))
            compatibility.append({"source_cluster":s["index"], "reading_cluster":r["index"],
                                  "same_base":base_ok, "explicit_marks_preserved":marks_ok,
                                  "added_marks":list((Counter(r["marks"])-Counter(s["marks"])).elements())})
            if not base_ok or not marks_ok:
                problems.append(_problem("READING_CONFLICT", "Selected reading changes a source base or explicit mark", "BLOCK", [r["index"]]))
    if surface != text:
        _op(operations, "READING_SELECTION", range(len(reading_clusters)),
            source_id=selected["source_id"], mode=selected["mode"],
            source_is_lexical_authority=False, added_marks_are_input_assistance=True)
    if not surface:
        problems.append(_problem("EMPTY_OCCURRENCE", "No lexical material to compile", "DEFER"))
    if selected.get("status") not in (None, "PASS"):
        problems.append(_problem("READING_NOT_ACCEPTED", "The selected reading is not accepted by its supplying layer", "DEFER"))

    article = len(reading_clusters) >= 3 and reading_clusters[0]["base"] in ("ا", "ٱ") and reading_clusters[1]["base"] == "ل" and (roles.get("definite") is True or roles.get("hamzat_wasl") == "ARTICLE")
    lexical_wasl = bool(reading_clusters) and reading_clusters[0]["base"] in ("ا", "ٱ") and roles.get("hamzat_wasl") in ("VERB", "IMPERATIVE", "LEXEME")
    solar = article and reading_clusters[2]["base"] in SOLAR and SHADDA in reading_clusters[2]["marks"]
    owned_by_op, consumed = {}, set()
    tanwin_info = None
    ta_info = None
    i = 0
    while i < len(reading_clusters):
        g = reading_clusters[i]
        if i in consumed:
            i += 1
            continue
        c, marks = g["base"], g["marks"]
        unknown = [m for m in marks if m not in SUPPORTED_MARKS]
        if unknown:
            problems.append(_problem("UNSUPPORTED_MARK", "A combining mark has no declared A116 operation", "DEFER", [i], marks=unknown))
        vowel_marks = [m for m in marks if m in STATES]
        if len(vowel_marks) > 1 or len(set(marks)) != len(marks):
            problems.append(_problem("CONFLICTING_MARKS", "Multiple or repeated carrier states are not licensed", "BLOCK", [i]))
            i += 1
            continue
        if article and i == 0:
            if marks and any(m not in (FATHA,) for m in marks):
                problems.append(_problem("ARTICLE_HAMZA_MARK", "Declared article onset accepts only the stated fatha", "BLOCK", [i]))
            op = _op(operations, "ARTICLE_WASL", [0], boundary=boundary_before,
                     original_spelling=c, citation_parent=112, original_alif_remains_distinct=True)
            owned_by_op[i] = op
            if boundary_before in ("IBTIDA", "FASL"):
                units.append(_unit("ء", "a", [i], "ARTICLE_WASL_INITIAL", occurrence_id))
            i += 1
            continue
        if lexical_wasl and i == 0:
            if len(vowel_marks) != 1 or vowel_marks[0] not in (FATHA, DAMMA, KASRA) or any(m not in (FATHA, DAMMA, KASRA) for m in marks):
                problems.append(_problem("WASL_ONSET_STATE_REQUIRED", "Lexical hamzat wasl needs its explicitly selected initial short state", "DEFER", [0]))
                i += 1
                continue
            initial_state = STATES[vowel_marks[0]]
            parent = 112 + "aui".index(initial_state)
            op = _op(operations, "LEXICAL_HAMZAT_WASL", [0], boundary=boundary_before,
                     original_spelling=c, citation_parent=parent, declared_role=roles["hamzat_wasl"])
            owned_by_op[0] = op
            if boundary_before in ("IBTIDA", "FASL"):
                units.append(_unit("ء", initial_state, [0], "LEXICAL_HAMZAT_WASL_INITIAL", occurrence_id))
            i += 1
            continue
        if article and i == 1:
            if solar:
                if marks and marks != [SUKUN]:
                    problems.append(_problem("SOLAR_LAM_MARK", "Solar lam cannot carry an explicit vowel here", "BLOCK", [i]))
                op = _op(operations, "SOLAR_LAM", [1,2], underlying_lam_source116=91,
                         target_carrier=reading_clusters[2]["base"], explicit_shadda=True)
                owned_by_op[i] = op
            else:
                if vowel_marks and vowel_marks != [SUKUN]:
                    problems.append(_problem("ARTICLE_LAM_STATE", "Article lam needs sukun in the lunar rule", "BLOCK", [i]))
                if reading_clusters[2]["base"] in SOLAR:
                    problems.append(_problem("SOLAR_SHADDA_MISSING", "Solar article needs its explicit assimilated reading", "DEFER", [2]))
                units.append(_unit("ل", "S", [i], "ARTICLE_LAM", occurrence_id))
                owned_by_op[i] = _op(operations, "ARTICLE_WASL", [i], lam_state="S", declared_article=True)
            i += 1
            continue
        if c == "آ":
            if marks:
                problems.append(_problem("MADDA_MARK_CONFLICT", "This profile accepts bare madda hamza only", "DEFER", [i]))
            units.append(_unit("ء", "aa", [i], "MADDA_HAMZA", occurrence_id))
            _op(operations, "MADDA_HAMZA", [i], hamza_parent=112, alif_parent=3)
            i += 1
            continue
        carrier = SEATED.get(c, c)
        if c in SEATED:
            _op(operations, "HAMZA_SEAT", [i], spelling=c, carrier="ء", seat_preserved=True)
        if c == "ة":
            if i != len(reading_clusters)-1 or roles.get("ta_marbuta") is not True:
                problems.append(_problem("TA_MARBUTA_ROLE_REQUIRED", "Terminal ta marbuta requires its explicit role", "DEFER", [i]))
                i += 1
                continue
            carrier = "ت"
            ta_info = {"cluster":i, "citation_carrier":"ت"}
            _op(operations, "TA_MARBUTA", [i], phase="CITATION", carrier="ت")
        if carrier not in INDEX or carrier == "ا":
            code = "UNLICENSED_ALIF" if c in ("ا", "ٱ", "ى") else "UNSUPPORTED_BASE"
            severity = "DEFER"
            if c == "ا" and vowel_marks:
                code = "BLOCK_RESERVED_MOVING_ALIF" if vowel_marks[0] != SUKUN else "BLOCK_INDEPENDENT_MADD_SUPPORT"
                severity = "BLOCK"
            problems.append(_problem(code, "Base has no licensed ordinary carrier/state at this position", severity, [i], base=c))
            i += 1
            continue
        if not vowel_marks:
            problems.append(_problem("MISSING_STATE", "No explicit state; the compiler does not invent vocalization", "DEFER", [i], carrier=carrier))
            i += 1
            continue
        vm = vowel_marks[0]
        state = STATES[vm]
        if SHADDA in marks:
            if state == "S":
                problems.append(_problem("SHADDA_SUKUN_CONFLICT", "Selected citation needs a vowel on the second geminate half", "BLOCK", [i]))
            units.append(_unit(carrier, "S", [i], "SHADDA_FIRST", occurrence_id))
            _op(operations, "SHADDA", [i], first_state="S", second_state=state)
        owners, long_state = [i], None
        if DAGGER in marks:
            if state != "a" or vm in TANWIN:
                problems.append(_problem("DAGGER_WITHOUT_FATHA", "Dagger alif requires an explicit short fatha", "BLOCK", [i]))
            else:
                long_state = "aa"
                _op(operations, "DAGGER_ALIF", [i], dependent_parent=3)
        elif vm not in TANWIN and i+1 < len(reading_clusters):
            nxt = reading_clusters[i+1]
            nb, nm = nxt["base"], nxt["marks"]
            is_support = ((state == "a" and nb == "ا") or (state == "u" and nb == "و") or (state == "i" and nb == "ي")) and (not nm or nm == [SUKUN])
            maqsura = state == "a" and nb == "ى" and i+1 == len(reading_clusters)-1 and not nm and roles.get("alif_maqsura") is True
            if is_support or maqsura:
                long_state = state*2
                owners.append(i+1)
                consumed.add(i+1)
                if maqsura:
                    _op(operations, "ALIF_MAQSURA", [i,i+1], original_spelling="ى", dependent_parent=3)
        if vm in TANWIN:
            terminal_index = i
            if vm == FATHATAN and i+1 == len(reading_clusters)-1 and reading_clusters[i+1]["base"] == "ا" and not reading_clusters[i+1]["marks"]:
                consumed.add(i+1)
                terminal_index = i+1
                op = _op(operations, "TANWIN_WASL", [i,i+1], support_alif_is_orthographic=True)
                owned_by_op[i+1] = op
            if terminal_index != len(reading_clusters)-1:
                problems.append(_problem("NONTERMINAL_TANWIN", "This reading profile requires terminal tanwin", "BLOCK", [i]))
            units.append(_unit(carrier, state, owners, "TANWIN_VOWEL", occurrence_id))
            main_index = len(units)-1
            units.append(_unit("ن", "S", [i], "TANWIN_NUN", occurrence_id))
            tanwin_info = {"cluster":i, "state":state, "main_index":main_index, "nun_index":len(units)-1}
            _op(operations, "TANWIN_WASL", [i], vowel_state=state, nun_source116=99)
        else:
            units.append(_unit(carrier, long_state or state, owners, "LONG" if long_state else "SHORT_OR_STILL", occurrence_id))
            _op(operations, "A116_LONG" if long_state else "A116_SHORT", owners,
                carrier=carrier, state=long_state or state, type_id=units[-1]["type_id"])
        i += 1
    _renumber(units, occurrence_id+":citation")
    citation_units = deepcopy(units)
    # Operate on the selected explicit citation, preserving that citation intact.
    if boundary_after in ("WAQF", "FASL") and units:
        if tanwin_info:
            k = tanwin_info["main_index"]
            old = units[k]
            units.pop(tanwin_info["nun_index"])
            if ta_info:
                units[k] = _unit("ه", "S", old["reading_cluster_owners"], "TA_MARBUTA_WAQF", occurrence_id)
                _op(operations, "TA_MARBUTA", [ta_info["cluster"]], phase="WAQF", input_type_id=old["type_id"], output_type_id=units[k]["type_id"])
            elif tanwin_info["state"] == "a":
                units[k] = _unit(old["carrier"], "aa", old["reading_cluster_owners"], "WAQF_FATHATAN", occurrence_id)
                _op(operations, "WAQF_FATHATAN", [tanwin_info["cluster"]], input_type_id=old["type_id"], output_type_id=units[k]["type_id"])
            else:
                units[k] = _unit(old["carrier"], "S", old["reading_cluster_owners"], "WAQF_TANWIN", occurrence_id)
                _op(operations, "WAQF", [tanwin_info["cluster"]], input_type_id=old["type_id"], output_type_id=units[k]["type_id"], tanwin_removed=True)
        elif ta_info:
            old = units[-1]
            units[-1] = _unit("ه", "S", old["reading_cluster_owners"], "TA_MARBUTA_WAQF", occurrence_id)
            _op(operations, "TA_MARBUTA", [ta_info["cluster"]], phase="WAQF", input_type_id=old["type_id"], output_type_id=units[-1]["type_id"])
        elif units[-1]["state"] in ("a", "u", "i"):
            # Only transform the last literal carrier, not an earlier partial
            # parse whose unknown suffix happens to have been omitted.
            last_owned = max(units[-1]["reading_cluster_owners"])
            if last_owned == len(reading_clusters)-1:
                old = units[-1]
                units[-1] = _unit(old["carrier"], "S", old["reading_cluster_owners"], "WAQF_SHORT", occurrence_id)
                _op(operations, "WAQF", old["reading_cluster_owners"], input_type_id=old["type_id"], output_type_id=units[-1]["type_id"])
        if boundary_after == "FASL":
            _op(operations, "FASL", [], direction="AFTER")
    if boundary_before in ("IBTIDA", "FASL"):
        _op(operations, "IBTIDA", [], boundary=boundary_before)
    _renumber(units, occurrence_id)
    incomplete = any(p["status"]=="DEFER" for p in problems) and not any(p["status"]=="BLOCK" for p in problems)
    syllables, syllable_problems = _syllabify(units, allow_initial_pending=boundary_before=="WASL", partial=incomplete)
    problems.extend(syllable_problems)
    boundary_obligations = [p for p in problems if p["code"] == "WASL_PREDECESSOR_REQUIRED"]
    intrinsic = [p for p in problems if p["code"] != "WASL_PREDECESSOR_REQUIRED"]
    # Every original character has exactly one provenance owner.  Generated
    # phonetic units may share a grapheme (shadda/tanwin); ownership is not loss.
    character_ownership = []
    cluster_correspondence = len(source_clusters) == len(reading_clusters)
    for s in source_clusters:
        ri = s["index"] if cluster_correspondence else None
        output_ids = [u["id"] for u in units if ri in u["reading_cluster_owners"]] if ri is not None else []
        op_ids = [o["id"] for o in operations if ri in o["reading_cluster_indices"]] if ri is not None else []
        unresolved = [p["code"] for p in intrinsic if ri in p.get("reading_cluster_indices", [])] if ri is not None else ["READING_BASE_COUNT_MISMATCH"]
        for pos in range(s["start"], s["end"]):
            ch = surface[pos]
            is_unknown_mark = unicodedata.combining(ch) and ch not in SUPPORTED_MARKS
            character_ownership.append({"character":ch, "cp_start":sp["cp_start"]+pos,
                                        "cp_end":sp["cp_start"]+pos+1,
                                        "utf16_start":sp["utf16_start"]+u16len(surface[:pos]),
                                        "utf16_end":sp["utf16_start"]+u16len(surface[:pos+1]),
                                        "owner":{"occurrence_id":occurrence_id, "source_cluster":s["index"]},
                                        "reading_cluster":ri, "unit_ids":output_ids,
                                        "operation_ids":op_ids,
                                        "status":"RESIDUAL" if unresolved or is_unknown_mark or (not output_ids and not op_ids) else "MAPPED",
                                        "residual_codes":unresolved})
    # Reading characters also retain exact offsets, including all added marks.
    reading_ownership = []
    for g in reading_clusters:
        output_ids = [u["id"] for u in units if g["index"] in u["reading_cluster_owners"]]
        op_ids = [o["id"] for o in operations if g["index"] in o["reading_cluster_indices"]]
        for pos in range(g["start"], g["end"]):
            reading_ownership.append({"character":text[pos], "cp_start":pos, "cp_end":pos+1,
                                      "utf16_start":u16len(text[:pos]), "utf16_end":u16len(text[:pos+1]),
                                      "reading_cluster":g["index"], "unit_ids":output_ids,
                                      "operation_ids":op_ids})
    mapped = sum(x["status"] == "MAPPED" for x in character_ownership)
    used_parents = list(dict.fromkeys(p for u in citation_units+units+operations for p in u["source116_parent_ids"]))
    record = {"schema":"a116_occurrence.v13.1", "inputs":inputs, "id":occurrence_id,
              "surface":surface, "span":sp, "selected_reading":selected,
              "role":roles, "boundaries":{"before":boundary_before, "after":boundary_after},
              "basis":{"schema":frozen["data"]["schema"], "sha256_integrity_only":frozen["sha"],
                       "source116_count":116, "derived84_count":84,
                       "profile":"a116_declared_reading_rules.v13.1"},
              "compatibility":compatibility, "source_clusters":source_clusters,
              "reading_clusters":reading_clusters, "citation_units":citation_units,
              "units":units, "operations":operations, "syllables":syllables,
              "source116_parents":[deepcopy(frozen["sources"][p]) for p in used_parents],
              "character_ownership":character_ownership, "reading_character_ownership":reading_ownership,
              "boundary_obligations":boundary_obligations, "residuals":problems,
              "intrinsic_status":_status(intrinsic), "status":_status(problems),
              "coverage":{"source_characters":len(surface), "owned_source_characters":len(character_ownership),
                          "mapped_source_characters":mapped, "residual_source_characters":len(surface)-mapped,
                          "ordered_C_slots":len(units), "source116_parent_occurrences":sum(len(u["source116_parent_ids"]) for u in units),
                          "long84_units":sum(u["type_id"] >=116 for u in units)},
              "authority":"DECLARED_READING_TO_FROZEN_116; INTEGRATED_LEXICAL_MEANING_REFERENCE_AND_EVIDENCE_GATES_REQUIRED"}
    return record


def verify_occurrence(record):
    """Strict replay.  A caller cannot promote a certificate by editing flags."""
    if not isinstance(record, dict) or record.get("schema") != "a116_occurrence.v13.1":
        return False
    try:
        rebuilt = compile_occurrence(**deepcopy(record["inputs"]))
        return _canon(rebuilt) == _canon(record)
    except (KeyError, ValueError, TypeError, IndexError):
        return False


def _lookup(mapping, token):
    mapping = mapping or {}
    keys = [str(token["index"]), token["index"], token["id"],
            f"{token['span']['cp_start']}:{token['span']['cp_end']}"]
    for key in keys:
        if key in mapping:
            return mapping[key]
    return None


def compile_document(document, readings=None, roles=None, boundary_plan=None):
    if not isinstance(document, dict) or not isinstance(document.get("text"), str):
        raise TypeError("document requires exact text")
    text = document["text"]
    tokens = tokenize(text)
    lexical = [t for t in tokens if not all(ch in STRUCTURAL for ch in t["surface"])]
    lexical_indices = [t["index"] for t in lexical]
    occurrences, structural, problems, boundary_decisions = [], [], [], []
    for t in tokens:
        if t["index"] not in lexical_indices:
            structural.append({**t, "kind":"STRUCTURAL_MARK", "status":"PASS", "a116_phonetic_unit":False,
                               "authority":"DECLARED_ORTHOGRAPHIC_SEGMENTATION", "characters":[{"character":c,"cp_start":t["span"]["cp_start"]+j,"cp_end":t["span"]["cp_start"]+j+1,"utf16_start":t["span"]["utf16_start"]+u16len(t["surface"][:j]),"utf16_end":t["span"]["utf16_start"]+u16len(t["surface"][:j+1])} for j,c in enumerate(t["surface"])]})
            continue
        li = lexical_indices.index(t["index"])
        prev = lexical[li-1] if li else None
        nxt = lexical[li+1] if li+1 < len(lexical) else None
        left_gap = text[prev["span"]["cp_end"]:t["span"]["cp_start"]] if prev else ""
        right_gap = text[t["span"]["cp_end"]:nxt["span"]["cp_start"]] if nxt else ""
        before = "IBTIDA" if prev is None else ("FASL" if any(c in PAUSES for c in left_gap) else "WASL")
        after = "WAQF" if nxt is None else ("FASL" if any(c in PAUSES for c in right_gap) else "WASL")
        plan = _lookup(boundary_plan, t)
        if isinstance(plan, dict):
            before = plan.get("before", plan.get("boundary_before", before))
            after = plan.get("after", plan.get("boundary_after", after))
        rec = compile_occurrence(t["surface"], _lookup(readings, t), occurrence_id=t["id"], span=t["span"],
                                 boundary_before=before, boundary_after=after, role=_lookup(roles, t))
        occurrences.append(rec)
        problems.extend({**p, "occurrence_id":t["id"]} for p in rec["residuals"] if p["code"] != "WASL_PREDECESSOR_REQUIRED")
    segments, active = [], []
    for i, rec in enumerate(occurrences):
        b = rec["boundaries"]
        if i == 0 and b["before"] == "WASL":
            problems.append(_problem("DOCUMENT_INITIAL_WASL", "Document begins with an unresolved predecessor", "DEFER", occurrence_id=rec["id"]))
        if i:
            prev = occurrences[i-1]
            was_join = prev["boundaries"]["after"] == "WASL"
            is_join = b["before"] == "WASL"
            if was_join != is_join:
                problems.append(_problem("BOUNDARY_MISMATCH", "Adjacent occurrences disagree on connected/separated boundaries", "BLOCK", occurrence_ids=[prev["id"],rec["id"]]))
        if b["before"] in ("IBTIDA", "FASL") and active:
            segments.append(active)
            active = []
        active.append(rec)
        if b["after"] in ("WAQF", "FASL"):
            segments.append(active)
            active = []
    if active:
        segments.append(active)
    if occurrences and occurrences[-1]["boundaries"]["after"] == "WASL":
        problems.append(_problem("DOCUMENT_FINAL_WASL", "Document ends with an open successor boundary", "DEFER", occurrence_id=occurrences[-1]["id"]))
    segment_certificates = []
    for si, seg in enumerate(segments):
        seq = [deepcopy(u) for rec in seg for u in rec["units"]]
        input_unit_order = [u["id"] for u in seq]
        boundary_operations = []
        for left, right in zip(seg, seg[1:]):
            if not left["units"] or not right["units"]:
                continue
            previous = left["units"][-1]
            following = right["units"][0]
            dropped_wasl = any(op["rule_id"] in ("ARTICLE_WASL", "LEXICAL_HAMZAT_WASL") and op["details"].get("boundary") == "WASL" for op in right["operations"])
            boundary_rule = None
            target_state = None
            if previous["state"] in ("aa", "uu", "ii") and following["state"] == "S" and dropped_wasl:
                boundary_rule, target_state = "WASL_LONG_BEFORE_STILL", previous["state"][0]
            elif (previous["carrier"] == "ن" and previous["state"] == "S" and previous["reason"] == "TANWIN_NUN"
                  and following["state"] == "S" and dropped_wasl):
                boundary_rule, target_state = "TANWIN_WASL_KASR", "i"
            elif (previous["state"] == "S" and previous["carrier"] not in ("و", "ي") and following["state"] == "S" and dropped_wasl
                  and (left["role"].get("hamzat_wasl") == "IMPERATIVE" or left["role"].get("mood") == "JUSSIVE")):
                boundary_rule, target_state = "VERB_WASL_KASR", "i"
            if boundary_rule:
                replacement = _unit(previous["carrier"], target_state, previous["reading_cluster_owners"], boundary_rule, previous["occurrence_id"])
                replacement["id"] = previous["id"]+":wasl"
                replacement["position"] = previous["position"]
                replacement["parent_unit_id"] = previous["id"]
                pos = next(i for i,u in enumerate(seq) if u["id"]==previous["id"])
                seq[pos] = replacement
                _op(boundary_operations, boundary_rule, [],
                    input_type_id=previous["type_id"], output_type_id=replacement["type_id"],
                    source_unit_id=previous["id"], output_unit_id=replacement["id"],
                    source_occurrence_ids=[left["id"], right["id"]],
                    successor_unit_id=following["id"], source_unit=deepcopy(previous),
                    governing_role=deepcopy(left["role"]))
        # A syllable built across an unknown word cannot certify the missing path.
        intrinsic_ok = all(rec["intrinsic_status"] == "PASS" for rec in seg)
        intrinsic_blocked = any(rec["intrinsic_status"] == "BLOCK" for rec in seg)
        syl, errs = _syllabify(seq, allow_initial_pending=False, partial=not intrinsic_ok and not intrinsic_blocked)
        if not intrinsic_ok:
            errs.append(_problem("SEGMENT_INCOMPLETE_ANCESTRY", "At least one occurrence in the connected segment has unresolved intrinsic prerequisites", "DEFER"))
        problems.extend({**p, "segment_id":f"segment{si}"} for p in errs)
        status = _status(errs)
        segment_certificates.append({"id":f"segment{si}", "occurrence_ids":[r["id"] for r in seg],
                                     "input_unit_order":input_unit_order,
                                     "unit_order":[u["id"] for u in seq], "realized_units":seq,
                                     "operations":boundary_operations, "syllables":syl,
                                     "rule_id":"BOUNDARY_JOIN", "status":status, "residuals":errs})
        for rec in seg:
            boundary_decisions.append({"occurrence_id":rec["id"], "local_status":rec["status"],
                                       "intrinsic_status":rec["intrinsic_status"],
                                       "boundary_context_status":status,
                                       "integrated_boundary_status":status if rec["intrinsic_status"]=="PASS" else rec["intrinsic_status"],
                                       "segment_id":f"segment{si}",
                                       "closed_obligations":[p["code"] for p in rec["boundary_obligations"]] if status=="PASS" else []})
    whitespace = [{"character":c, "cp_start":i, "cp_end":i+1, "utf16_start":u16len(text[:i]), "utf16_end":u16len(text[:i+1]), "kind":"WHITESPACE", "status":"PRESERVED"} for i,c in enumerate(text) if c.isspace()]
    occupied = [x["cp_start"] for r in occurrences for x in r["character_ownership"]]
    occupied += [x["cp_start"] for r in structural for x in r["characters"]]
    occupied += [x["cp_start"] for x in whitespace]
    ownership_ok = sorted(occupied) == list(range(len(text)))
    if not ownership_ok:
        problems.append(_problem("CHARACTER_OWNERSHIP_GAP_OR_OVERLAP", "Every original codepoint must have exactly one owner", "BLOCK"))
    if not occurrences:
        problems.append(_problem("NO_LEXICAL_OCCURRENCE", "The document has no lexical occurrence", "DEFER"))
    return {"schema":"a116_document.v13.1", "document":deepcopy(document), "original_text":text,
            "inputs":{"document":deepcopy(document), "readings":deepcopy(readings), "roles":deepcopy(roles), "boundary_plan":deepcopy(boundary_plan)},
            "basis":{"source116_count":116,"derived84_count":84,"sha256_integrity_only":basis()["sha"]},
            "tokens":tokens, "occurrences":occurrences, "structural_marks":structural,
            "whitespace":whitespace, "segments":segment_certificates,
            "occurrence_boundary_decisions":boundary_decisions,
            "status":_status(problems), "residuals":problems,
            "coverage":{"all_source_characters_owned_once":ownership_ok,
                        "source_characters":len(text), "source_utf16_units":u16len(text),
                        "lexical_occurrences":len(occurrences), "lexical_intrinsic_pass":sum(r["intrinsic_status"]=="PASS" for r in occurrences),
                        "lexical_in_context_pass":sum(r["integrated_boundary_status"]=="PASS" for r in boundary_decisions),
                        "source116_parent_occurrences":sum(r["coverage"]["source116_parent_occurrences"] for r in occurrences),
                        "long84_units":sum(r["coverage"]["long84_units"] for r in occurrences),
                        "assisted_occurrences":sum(r["selected_reading"]["mode"] != "RAW_SURFACE" for r in occurrences),
                        "structural_marks":len(structural), "whitespace_characters":len(whitespace)},
            "default_boundary_policy":"PUNCTUATION_AS_DECLARED_PAUSE; OVERRIDE_WITH_EXPLICIT_BOUNDARY_PLAN",
            "authority":"FULL_FORMAL_READING_PATH; ALL_FURTHER_PREREQUISITES_REMAIN_IN_THE_SAME_INTEGRATED_V13_CONTRACT"}


def verify_document(record):
    if not isinstance(record, dict) or record.get("schema") != "a116_document.v13.1":
        return False
    try:
        return _canon(compile_document(**deepcopy(record["inputs"]))) == _canon(record)
    except (KeyError, TypeError, ValueError, IndexError):
        return False


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("text")
    parser.add_argument("--reading")
    parser.add_argument("--article", action="store_true")
    args = parser.parse_args()
    result = compile_occurrence(args.text, args.reading, role={"definite":args.article, "alif_maqsura":True, "ta_marbuta":True})
    print(json.dumps(result, ensure_ascii=False, indent=2))
