"""Use saved learned weights on a declared source116 identifier.

This returns a candidate. It does not run the V13 target oracle or silently
correct the prediction. Identity and parent lookup are deterministic renderer
services; the three surface decisions come from learned NumPy weights.
"""
import argparse
import json
from pathlib import Path
import numpy as np
import experiment as e


def main():
    p = argparse.ArgumentParser()
    p.add_argument("--source116", type=int, required=True)
    p.add_argument("--boundary", choices=e.BOUNDS, required=True)
    p.add_argument("--shadda", action="store_true")
    p.add_argument("--tanwin", action="store_true")
    p.add_argument("--model", choices=["flat", "invariant", "modular"], default="modular")
    p.add_argument("--seed", type=int, choices=[17,29,43], default=17)
    a = p.parse_args()
    carrier_index, state = divmod(a.source116, 4)
    if not (1 <= carrier_index <= 28 and state < 3):
        raise SystemExit("Outside this trained probe: ordinary carrier plus explicit a/u/i is required.")
    carrier = e.oracle.CARRIERS[carrier_index]
    row = {"input": {"carrier": carrier, "carrier_index_local":carrier_index-1,
                     "vowel":state,"shadda":int(a.shadda),"tanwin":int(a.tanwin),
                     "boundary":e.BOUNDS.index(a.boundary)}}
    m = e.Model(a.model,a.seed)
    with np.load(e.ROOT / "results" / f"{a.model}_{a.seed}.npz") as saved:
        for i, net in enumerate(m.nets):
            for key in net.params:
                net.params[key]=saved[f"net{i}_{key}"].copy()
    result=m.predict(e.features([row]))[0]
    units=e.render(carrier,result)
    print(json.dumps({
        "rank":"CANDIDATE",
        "scope":"SYNTHETIC_LOCAL_A116_CONTRACT_PROBE",
        "input_source116_id":a.source116,
        "carrier":carrier,
        "learned_heads":{"double":bool(result[0]),"final_state":e.STATES[int(result[1])],"inserted_nun":bool(result[2])},
        "units_with_deterministically_resolved_ancestry":units,
        "posthoc_oracle_correction":False,
        "not_claimed":"lexical usage, meaning, general Arabic, independently licensed inference"
    },ensure_ascii=False,indent=2))


if __name__ == "__main__":
    main()
