"""A small actual neural-learning experiment on frozen V13 contract outputs.

Requires only NumPy. Run `python experiment.py` to regenerate data and retrain.
There is no post-hoc verifier correction in model prediction or test scoring.
The exact V13 executable is the label oracle, so this is contract distillation
with supplied modular priors, not discovery of Arabic or natural-language QA.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import sys
import time

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / "oracle"))
import a116_v13 as oracle

STATES = ["a", "u", "i", "S", "aa"]
BOUNDS = ["WASL", "WAQF", "FASL"]
SHORT = ["َ", "ُ", "ِ"]
TANWIN = ["ً", "ٌ", "ٍ"]
SIZES = (28, 3, 2, 2, 3)
HEAD_SIZES = (2, 5, 2)


def canonical(obj):
    return json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def features(rows):
    x = np.zeros((len(rows), sum(SIZES)), dtype=np.float64)
    offsets = np.cumsum([0, *SIZES[:-1]])
    for i, row in enumerate(rows):
        f = row["input"]
        values = [f["carrier_index_local"], f["vowel"], f["shadda"], f["tanwin"], f["boundary"]]
        for off, value in zip(offsets, values):
            x[i, off + value] = 1.0
    return x


def render(carrier, prediction):
    double, vowel, nun = map(int, prediction)
    spec = []
    if double:
        spec.append((carrier, "S"))
    spec.append((carrier, STATES[vowel]))
    if nun:
        spec.append(("ن", "S"))
    frozen = oracle.basis()["rows"]
    resolved = []
    for c, s in spec:
        tid = 4 * oracle.INDEX[c] + ["a", "u", "i", "S"].index(s) if s != "aa" else 116 + (oracle.INDEX[c] - 1) * 3
        r = frozen[tid]
        resolved.append({"carrier": c, "state": s, "source116_parent_ids": r["source116_parent_ids"]})
    return resolved


def dataset(protocol):
    carriers = [c for c in oracle.CARRIERS if c != "ا"]
    order = np.random.default_rng(protocol["split_seed"]).permutation(len(carriers)).tolist()
    group = {i: "train" if k < 20 else "validation" if k < 24 else "test" for k, i in enumerate(order)}
    rows = []
    for ci, carrier in enumerate(carriers):
        for h in range(3):
            for shadda in (0, 1):
                for tanwin in (0, 1):
                    for boundary in range(3):
                        surface = "بَ" + carrier + ("ّ" if shadda else "") + (TANWIN if tanwin else SHORT)[h]
                        ident = f"p{len(rows):04d}"
                        record = oracle.compile_occurrence(surface, occurrence_id=ident, boundary_after=BOUNDS[boundary])
                        assert record["status"] == "PASS", (surface, BOUNDS[boundary], record["residuals"])
                        assert oracle.verify_occurrence(record)
                        tail = record["units"][1:]
                        self_units = [u for u in tail if u["reason"] != "TANWIN_NUN"]
                        nun_units = [u for u in tail if u["reason"] == "TANWIN_NUN"]
                        target = [int(len(self_units) == 2), STATES.index(self_units[-1]["state"]), int(bool(nun_units))]
                        expected = [{"carrier": u["carrier"], "state": u["state"], "source116_parent_ids": u["source116_parent_ids"]} for u in tail]
                        assert render(carrier, target) == expected
                        conj = bool(shadda and tanwin)
                        split = ("composition" if conj else "train") if group[ci] == "train" else (group[ci] + ("_composition" if conj else "_familiar"))
                        rows.append({
                            "id": ident,
                            "surface": surface,
                            "input": {"carrier": carrier, "carrier_index_local": ci, "vowel": h, "shadda": shadda, "tanwin": tanwin, "boundary": boundary},
                            "carrier_partition": group[ci], "split": split,
                            "target": target,
                            "expected_units": expected,
                            "source116_input_id": 4 * oracle.INDEX[carrier] + h,
                            "certificate_sha256_integrity_only": hashlib.sha256(canonical(record).encode()).hexdigest(),
                            "authority": "SYNTHETIC_V13_DECLARED_PHONOLOGICAL_CONTRACT_PROBE_NOT_LEXICAL_ATTESTATION"
                        })
    return rows, {g: [carriers[i] for i in order if group[i] == g] for g in ("train", "validation", "test")}


class MLP:
    """Small trainable tanh network, independent softmax heads, manual Adam."""
    def __init__(self, input_dim, hidden_dim, heads, seed):
        rng = np.random.default_rng(seed)
        self.heads = tuple(heads)
        self.params = {
            "W1": rng.normal(0, np.sqrt(2 / (input_dim + hidden_dim)), (input_dim, hidden_dim)),
            "b1": np.zeros(hidden_dim),
            "W2": rng.normal(0, np.sqrt(2 / (hidden_dim + sum(heads))), (hidden_dim, sum(heads))),
            "b2": np.zeros(sum(heads))
        }
        self.m = {k: np.zeros_like(v) for k, v in self.params.items()}
        self.v = {k: np.zeros_like(v) for k, v in self.params.items()}
        self.t = 0

    @property
    def count(self):
        return sum(v.size for v in self.params.values())

    def forward(self, x):
        p = self.params
        hidden = np.tanh(x @ p["W1"] + p["b1"])
        logits = hidden @ p["W2"] + p["b2"]
        return hidden, logits

    def predict(self, x):
        logits = self.forward(x)[1]
        parts, start = [], 0
        for width in self.heads:
            parts.append(np.argmax(logits[:, start:start+width], axis=1))
            start += width
        return np.stack(parts, axis=1)

    def loss_gradient(self, x, y):
        hidden, logits = self.forward(x)
        grad = np.zeros_like(logits)
        loss, start = 0.0, 0
        for j, width in enumerate(self.heads):
            z = logits[:, start:start+width]
            z = z - np.max(z, axis=1, keepdims=True)
            probs = np.exp(z)
            probs /= probs.sum(axis=1, keepdims=True)
            loss -= np.log(probs[np.arange(len(y)), y[:, j]] + 1e-300).mean()
            probs[np.arange(len(y)), y[:, j]] -= 1
            grad[:, start:start+width] = probs / len(y)
            start += width
        gh = (grad @ self.params["W2"].T) * (1-hidden*hidden)
        return float(loss), {"W1": x.T @ gh, "b1": gh.sum(axis=0), "W2": hidden.T @ grad, "b2": grad.sum(axis=0)}

    def step(self, x, y, config):
        loss, grads = self.loss_gradient(x, y)
        self.t += 1
        for key, grad in grads.items():
            if key.startswith("W"):
                grad = grad + config["weight_decay"] * self.params[key]
            self.m[key] = .9 * self.m[key] + .1 * grad
            self.v[key] = .999 * self.v[key] + .001 * grad * grad
            m = self.m[key] / (1-.9**self.t)
            v = self.v[key] / (1-.999**self.t)
            self.params[key] -= config["learning_rate"] * m / (np.sqrt(v) + 1e-8)
        return loss


class Model:
    def __init__(self, name, seed):
        self.name = name
        if name == "modular":
            self.nets = [MLP(2, 8, (2,), seed), MLP(8, 24, (5,2), seed+100)]
            self.columns = [list(range(31, 33)), list(range(28, 31)) + list(range(33, 38))]
            self.ycols = [[0], [1, 2]]
        else:
            self.columns = [list(range(38)) if name == "flat" else list(range(28, 38))]
            self.nets = [MLP(len(self.columns[0]), 24, HEAD_SIZES, seed)]
            self.ycols = [[0,1,2]]

    @property
    def count(self):
        return sum(n.count for n in self.nets)

    def predict(self, x):
        return np.concatenate([n.predict(x[:, cols]) for n, cols in zip(self.nets, self.columns)], axis=1)

    def fit(self, x, y, config):
        history = []
        for i in range(config["steps"]):
            loss = sum(n.step(x[:, cols], y[:, ys], config) for n, cols, ys in zip(self.nets, self.columns, self.ycols))
            if i in (0, 9, 99, 399, config["steps"]-1):
                history.append({"step": i+1, "loss": loss, "training_exact": float(np.all(self.predict(x)==y, axis=1).mean())})
        return history

    def save(self, path):
        np.savez_compressed(path, **{f"net{i}_{k}": v for i, n in enumerate(self.nets) for k,v in n.params.items()})


def gradient_check():
    rng = np.random.default_rng(4)
    x = rng.normal(size=(4,3))
    y = np.array([[0,0],[1,2],[0,1],[1,0]])
    n = MLP(3, 4, (2,3), 7)
    _, grads = n.loss_gradient(x,y)
    worst = 0.0
    for key in n.params:
        idx = tuple(0 for _ in n.params[key].shape)
        old = n.params[key][idx]
        eps = 1e-6
        n.params[key][idx] = old + eps
        lp = n.loss_gradient(x,y)[0]
        n.params[key][idx] = old - eps
        lm = n.loss_gradient(x,y)[0]
        n.params[key][idx] = old
        worst = max(worst, abs((lp-lm)/(2*eps) - grads[key][idx]))
    assert worst < 1e-6, worst
    return worst


def metrics(rows, y, predictions):
    result = {}
    names = sorted(set(r["split"] for r in rows))
    for split in names:
        ids = [i for i,r in enumerate(rows) if r["split"] == split]
        correct = np.all(predictions[ids] == y[ids], axis=1)
        ancestry = [render(rows[i]["input"]["carrier"], predictions[i]) == rows[i]["expected_units"] for i in ids]
        result[split] = {"n": len(ids), "correct": int(correct.sum()), "exact": float(correct.mean()), "head_accuracy": (predictions[ids] == y[ids]).mean(axis=0).tolist(), "ancestry_exact": float(np.mean(ancestry))}
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=ROOT / "results")
    args = parser.parse_args()
    out = args.output
    out.mkdir(parents=True, exist_ok=True)
    protocol = json.loads((ROOT / "protocol.json").read_text())
    protocol_sha = digest(ROOT / "protocol.json")
    (out / "protocol_before_training.sha256").write_text(protocol_sha + "\n")
    check = gradient_check()
    rows, carriers = dataset(protocol)
    data_text = canonical(rows)
    (out / "dataset.json").write_text(data_text, encoding="utf-8")
    x = features(rows)
    y = np.array([r["target"] for r in rows], dtype=np.int64)
    train = np.array([r["split"] == "train" for r in rows])
    assert train.sum() == 540 and len(rows) == 1008
    assert not any(r["input"]["shadda"] and r["input"]["tanwin"] for r in rows if r["split"] == "train")
    experiments, all_preds = [], []
    for seed in protocol["seeds"]:
        for name in ("flat", "invariant", "modular"):
            model = Model(name, seed)
            before = metrics(rows,y,model.predict(x))
            t0 = time.perf_counter()
            history = model.fit(x[train], y[train], protocol["optimizer"])
            seconds = time.perf_counter()-t0
            # Held-out labels are used for evaluation only (before/after training),
            # never for gradients, model selection, or changing the fixed schedule.
            pred = model.predict(x)
            model.save(out / f"{name}_{seed}.npz")
            result = {"model":name,"seed":seed,"parameters":model.count,"training_seconds":seconds,"history":history,"before_training":before,"metrics":metrics(rows,y,pred)}
            experiments.append(result)
            all_preds.append({"model":name,"seed":seed,"predictions":pred.tolist()})
            print(json.dumps({"model":name,"seed":seed,"metrics":{k:v["exact"] for k,v in result["metrics"].items()}},ensure_ascii=False),flush=True)
    aggregate = {}
    for name in ("flat","invariant","modular"):
        runs = [r for r in experiments if r["model"] == name]
        aggregate[name] = {"parameters":runs[0]["parameters"],"splits":{split:{"n_per_seed":runs[0]["metrics"][split]["n"],"exact_mean":float(np.mean([r["metrics"][split]["exact"] for r in runs])),"exact_min":min(r["metrics"][split]["exact"] for r in runs),"exact_max":max(r["metrics"][split]["exact"] for r in runs),"counts":[r["metrics"][split]["correct"] for r in runs]} for split in runs[0]["metrics"]}}
    result = {"schema":"nabt_v13_learning_probe.v1","protocol_sha256":protocol_sha,"data_sha256":hashlib.sha256(data_text.encode()).hexdigest(),"seed_count":len(protocol["seeds"]),"case_count":len(rows),"train_case_count":int(train.sum()),"carrier_splits":carriers,"all_oracle_contracts_pass":True,"all_oracle_certificates_replayed":True,"gradient_max_abs_error":check,"runtime":{"python":sys.version.split()[0],"numpy":np.__version__},"oracle_sources":{str(p.relative_to(ROOT)):digest(p) for p in sorted((ROOT/"oracle").rglob("*")) if p.is_file() and "__pycache__" not in str(p)},"aggregate":aggregate,"runs":experiments,"exact_oracle_reference":1.0,"limits":protocol["not_claimed"]}
    assert digest(ROOT / "protocol.json") == protocol_sha
    (out / "results.json").write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding="utf-8")
    (out / "predictions.json").write_text(canonical(all_preds),encoding="utf-8")
    print(json.dumps({"result_file":str(out/"results.json"),"aggregate":aggregate},ensure_ascii=False),flush=True)


if __name__ == "__main__":
    main()
