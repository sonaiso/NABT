"""Independent evaluation adapter checks; full pinned corpus replay is a separate gate."""
from copy import deepcopy
import importlib.util
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("inflection_review", ROOT / "tools/inflection_evaluation.py")
review = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(review)


class IndependentInflectionReviewTests(unittest.TestCase):
    def test_frozen_material_and_disjoint_inventory(self):
        frozen, material, split, law = review.load_material()
        self.assertEqual(frozen["raw_case_count"], 74)
        self.assertEqual(len(material["cases"]), 74)
        self.assertEqual(len(split["excluded_verses"]), 48)
        self.assertEqual(len(law["admitted_rows"]), 45)
        self.assertEqual(len(law["excluded_class_case"]), 15)
        self.assertFalse(frozen["new_runtime_formal_or_table_read_before_freeze"])

    def test_boolean_cannot_be_a_numeric_sign(self):
        sign = {"class": 0, "case": 0, "sign": 1, "mode": 0, "origin": 0,
                "case_name": "nasb", "sign_name": "fatha", "mode_name": "overt", "origin_name": "original"}
        self.assertEqual(review.sign_view(sign)["case"], "nasb")
        for field in ("class", "case", "sign", "mode", "origin"):
            invalid = dict(sign, **{field: False})
            with self.assertRaises(ValueError):
                review.sign_view(invalid)

    def test_names_cannot_override_numeric_sign(self):
        sign = {"class": 0, "case": 2, "sign": 2, "mode": 0, "origin": 0,
                "case_name": "jarr", "sign_name": "fatha", "mode_name": "overt", "origin_name": "original"}
        with self.assertRaises(ValueError):
            review.sign_view(sign)

    def test_poisoning_changes_only_hidden_annotations(self):
        raw = b"# header\r\nLOCATION\tFORM\tTAG\tFEATURES\r\n(2:1:1:1)\tbaHorN\tN\tSTEM|POS:N|LEM:baHor|ROOT:bHr|M|NOM\r\n"
        poisoned = review.source_variant(raw, "case_mood_poisoned")
        erased = review.source_variant(raw, "case_mood_erased")
        self.assertEqual(poisoned, raw.replace(b"|NOM", b"|ACC"))
        self.assertEqual(erased, raw.replace(b"|NOM", b""))
        self.assertEqual(review.source_variant(raw, "heldout_qac"), raw)

    def test_semantic_comparison_ignores_ids_but_not_root(self):
        report = {"status": "DEFER", "frame_status": "CLOSED_FRAME_LANGUAGE", "semantic_facts": [], "relations": [],
                  "source_id": "a", "occurrences": [{"occurrence_id": "a", "surface": "بحر", "kind": "written_run",
                  "span": {"start": 0, "end": 6}, "status": "SOURCE_QUALIFIED_ALTERNATIVES", "obligations": [],
                  "readings": [{"reading_id": "one", "kind": "noun", "construction": None,
                                "lexical_features": {"root": "بحر"}, "sign_candidates": [], "nun_readings": [],
                                "segmentation": {"parts": [{"kind": "nominal_stem", "surface": "بحر",
                                                            "span": {"start": 0, "end": 6}}]}}]}]}
        changed = deepcopy(report)
        changed["source_id"] = "b"
        changed["occurrences"][0]["occurrence_id"] = "b"
        changed["occurrences"][0]["readings"][0]["reading_id"] = "two"
        self.assertEqual(review.semantic_view(report), review.semantic_view(changed))
        changed["occurrences"][0]["readings"][0]["lexical_features"]["root"] = "كتب"
        self.assertNotEqual(review.semantic_view(report), review.semantic_view(changed))

    def test_repeated_surface_preserves_two_targets(self):
        case = {"input": {"text": "بحر بحر"}, "target_surface": "بحر"}
        occurrences = [{"span": {"start": 0, "end": 6}}, {"span": {"start": 7, "end": 13}}]
        self.assertEqual(review.target_occurrences(case, {"occurrences": occurrences}), occurrences)
        with self.assertRaises(ValueError):
            review.target_occurrences(case, {"occurrences": occurrences[:1]})


if __name__ == "__main__":
    unittest.main()
