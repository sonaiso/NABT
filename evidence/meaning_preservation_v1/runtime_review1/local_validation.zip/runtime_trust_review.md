# Runtime trust review before publication

Reviewed head: `093ff687691ca51518c1d793c84e6b582016afdf`.
Base: `3dbe335a21ac838db3717f03ca2a5b5889e16e54`.

Scope: meaning_preservation_v1.py, CLI, native JSON main and its typed core,
fresh productive-clause handoff, receipt replay, current frozen contracts and
relevant evaluator gates. Repository instructions were reread. No repository
files were changed. No gold matrix or general test suite was rerun.

## Finding: mixed-invalid request classification differs

A 3023-byte request contains two identical case IDs. The second original also
has a 513-byte predicate (the declared limit is 512 UTF-8 bytes). Python rejects
the duplicate ID before parsing the second packet: INVALID_INPUT / INVALID_REQUEST.
The native main parses every case before the case-ID distinctness check and
therefore reports RESOURCE_EXHAUSTED / RESOURCE_LIMIT, exit 2. Neither grants
any authority; the Python wrapper reports verified=false and native_checked=false.

Evidence:
- duplicate_resource_request.json: exact canonical request bytes;
- duplicate_resource_precedence.json: head, input hash, complete request, Python
  proposal, runtime summary, native response and exit status.
- Request SHA256: 91b6ca3c86e00dd69a3bfde112c0976ac755ca9d35fb4d57d9a49867948af5a6.

This is an actionable diagnostic-consistency finding, not a false positive,
meaning-preservation counterexample, or invalidation of the retained 73-case
result. The frozen contracts put parsing/resource failures before semantic
comparisons but do not specify a universal priority table for every combination
of malformed fields and resource violations.

The smallest correction is to collect Python case IDs during validation and
check their uniqueness only after all original packets and transported payloads
have validated. It changes no accepted input and aligns this stage with the
native main. It does not prove identical precedence for every possible
multiply-invalid packet. Keep the first result and frozen gold unchanged.

## No further blocking finding in the reviewed scope

The native main decodes the complete transported string itself, validates its
inner schema, and calls the typed firstViolation operation. The Python wrapper
sends the installed request directly, checks the process result, and compares
the complete typed native decision. Missing/failed native execution cannot
produce a verified result. Unexpected process failure, resource exhaustion,
and contract disagreement have separate outcomes.

The productive path does not accept a caller's original semantic packet. It
reopens the original source through the existing producer and projects roles
only after a complete checked chain. An incomplete source chain returns before
constructing the meaning contract. The installed grammar remains the existing
finite DARABA VSO/VOS fragment.

Whole alternative records remain correlated. Source bindings and the complete
source context must survive decoding; deictic resolution uses source context,
while recipient context remains separate. Receipt verification reexecutes with
an independently supplied request and compares the complete typed receipt.

## Material limits that must remain explicit

- Authored mode treats the original packet as supplied premises. It does not
  acquire or establish the Arabic interpretation of the source_text field.
- Productive mode preserves the installed finite syntactic-role reading, not
  unrestricted Arabic meaning, intended referents, or event occurrence.
- The query retains tagged references and a fixed finite tuple of distinctions;
  it is not a proof that every potentially relevant meaning difference is in
  that tuple. Preserving source context is deliberately conservative.
- The native parser/codec and Python adapter remain tested implementation
  boundaries, without a claimed parser or Python refinement theorem.
- Ordinary receipts record the two adapter source files and the new native
  binary; the frozen evaluator supplies the wider transitive source/native
  identity checks. Neither hashes nor successful replay authenticate a speaker
  or prove world truth, and concurrent hostile mutation is outside the claimed
  isolation guarantees.
- No new human-to-human interpretation-agreement experiment, unrestricted
  ontology coverage, lifecycle-event adapter, or acquired-inference query
  projection is established by this meaning-preservation version.
