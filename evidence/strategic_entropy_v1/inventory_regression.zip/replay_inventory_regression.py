#!/usr/bin/env python3
"""Compare immutable evaluator revisions on independently specified Git inputs.

This exercises freeze provenance validation only. Synthetic native files are
hashed but never executed; gold/spec pins are replaced with fixture hashes.
It is not a native-build, import-isolation, or Arabic-coverage measurement.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from types import ModuleType


ROOT = Path(__file__).resolve().parents[3]
OUTPUT = Path(__file__).resolve().parent
REVISIONS = {
    "before": "a14332afb934bedd4f35bf2fb3d34c9004df52b7",
    "after": "180c198d233a6bf90f1968d6958a6771d234a7d2",
}
EVALUATOR = "tools/evaluate_aligned_acquisition.py"
SPEC = "docs/ACQUISITION_READER_SPEC.md"
LINKS = "evidence/licensed_inference_v1/source_links.json"
SOURCE_EVIDENCE = "evidence/aligned_acquisition_v1/source_evidence.json"

# This fixture is declared directly, without calling either inventory selector.
FILES = {
    "tools/aligned_acquisition.py": "# synthetic acquisition source\n",
    EVALUATOR: "# synthetic evaluator source\n",
    "tools/freeze_aligned_acquisition.py": "# synthetic freezer source\n",
    "tools/unused_runtime.py": "# tracked source unused by this fixture\n",
    "tests/test_fixture.py": "# independently specified frozen test\n",
    "src/nabt/__init__.py": "# synthetic package initializer\n",
    "src/nabt/data/fixture.json": "{}\n",
    "formal/Fixture.lean": "-- synthetic formal source\n",
    "formal/lean-toolchain": "leanprover/lean4:synthetic-fixture\n",
    "formal/lake-manifest.json": "{}\n",
    SPEC: "Independent synthetic specification pin.\n",
    LINKS: json.dumps({"sources": [{"local_path": "evidence/fixture/source.txt"}],
                       "source_registries": [{"path": "evidence/fixture/registry.json"}]}),
    "evidence/fixture/source.txt": "Synthetic retained source.\n",
    "evidence/fixture/registry.json": "{}\n",
    SOURCE_EVIDENCE: "{}\n",
    "docs/UNRELATED.md": "Optional extra file, outside the required inventory.\n",
}
NATIVE = {"formal/.lake/build/bin/" + name: "#!/bin/sh\nexit 0\n"
          for name in ("alignedAcquisition", "licensedInference")}
CASES = [
    ("complete_control", None, True, True),
    ("formal_source", "formal/Fixture.lean", True, False),
    ("toolchain", "formal/lean-toolchain", True, False),
    ("lake_manifest", "formal/lake-manifest.json", True, False),
    ("freezer_source", "tools/freeze_aligned_acquisition.py", True, False),
    ("unused_tool", "tools/unused_runtime.py", True, False),
    ("frozen_test", "tests/test_fixture.py", True, False),
    ("package_source", "src/nabt/__init__.py", True, False),
    ("runtime_data_control", "src/nabt/data/fixture.json", False, False),
    ("linked_source_control", "evidence/fixture/source.txt", False, False),
    ("linked_registry_control", "evidence/fixture/registry.json", False, False),
    ("source_evidence_control", SOURCE_EVIDENCE, False, False),
    ("optional_file_control", "docs/UNRELATED.md", True, True),
]


def digest(raw):
    return hashlib.sha256(raw).hexdigest()


def git(root, *args):
    env = dict(os.environ, GIT_AUTHOR_NAME="Inventory regression fixture",
               GIT_AUTHOR_EMAIL="fixture@example.invalid",
               GIT_COMMITTER_NAME="Inventory regression fixture",
               GIT_COMMITTER_EMAIL="fixture@example.invalid",
               GIT_AUTHOR_DATE="2000-01-01T00:00:00+00:00",
               GIT_COMMITTER_DATE="2000-01-01T00:00:00+00:00")
    return subprocess.run(["git", "-c", "core.hooksPath=/dev/null", "-c", "commit.gpgsign=false",
                           "-C", str(root), *args], env=env, check=True,
                          capture_output=True, timeout=30).stdout


def main():
    report = {
        "schema": "nabt.freeze-inventory-regression.v1",
        "measured_at_utc": datetime.now(timezone.utc).isoformat(),
        "scope": "Synthetic Git-backed freeze provenance validation in first and exposed phases.",
        "limitations": ["No native file is executed; the two native fixtures are synthetic.",
                        "Gold/specification hashes and matrix ancestry are fixture-specific overrides.",
                        "No real matrix, Arabic coverage, or native build correspondence is measured.",
                        "Before/after implementations are compiled directly from immutable Git blobs."],
        "script_sha256": digest(Path(__file__).read_bytes()),
        "python": sys.version,
        "fixture_files_utf8": FILES,
        "fixture_native_utf8": NATIVE,
        "implementations": {},
        "rows": [],
    }
    with (OUTPUT / "regression.log").open("x", encoding="utf-8") as log:
        def record(message):
            print(message, flush=True)
            log.write(message + "\n")
            log.flush()
        modules = {}
        for name, revision in REVISIONS.items():
            raw = git(ROOT, "show", revision + ":" + EVALUATOR)
            source = OUTPUT / (name + "_evaluator.py")
            with source.open("xb") as output:
                output.write(raw)
            module = ModuleType("inventory_regression_" + name)
            module.__file__ = str(source)
            exec(compile(raw, str(source), "exec", dont_inherit=True), module.__dict__)
            modules[name] = module
            report["implementations"][name] = {"commit": revision, "source_path": EVALUATOR,
                                                "source_sha256": digest(raw)}
            record(name + " implementation: " + revision + " sha256=" + digest(raw))
        with tempfile.TemporaryDirectory(prefix="nabt-inventory-regression-") as folder:
            root = Path(folder).resolve()
            for name, text in {**FILES, **NATIVE, "gold.json": "{}\n"}.items():
                path = root / name
                path.parent.mkdir(parents=True, exist_ok=True)
                path.write_bytes(text.encode("utf-8"))
                if name in NATIVE:
                    path.chmod(0o755)
            git(root, "init", "-q")
            git(root, "add", *FILES, "gold.json")
            git(root, "commit", "-qm", "Independent inventory regression fixture")
            commit = git(root, "rev-parse", "HEAD").decode().strip()
            report["fixture_commit"] = commit
            spec_hash, gold_hash = digest(FILES[SPEC].encode()), digest(b"{}\n")
            freeze = {"schema": "nabt.aligned-acquisition-code-freeze.v1", "commit": commit,
                      "spec_sha256": spec_hash, "gold": {"path": "gold.json", "sha256": gold_hash},
                      "files": {p: digest(text.encode()) for p, text in FILES.items()},
                      "native": {p: digest(text.encode()) for p, text in NATIVE.items()}}
            report["fixture_complete_manifest"] = freeze
            for module in modules.values():
                module.ROOT = root
                module.MATRIX_COMMIT = commit
                module.SPEC_SHA256 = spec_hash
                module.GOLD_SHA256 = gold_hash
            manifest = root / "freeze.json"
            for case, omitted, before_expected, after_expected in CASES:
                candidate = {**freeze, "files": {p: value for p, value in freeze["files"].items()
                                                  if p != omitted}}
                manifest.write_text(json.dumps(candidate), encoding="utf-8")
                for phase in ("first", "exposed"):
                    for name, expected in (("before", before_expected), ("after", after_expected)):
                        row = {"case": case, "phase": phase, "implementation": name,
                               "omitted": omitted, "expected_accepted": expected}
                        try:
                            _, evidence = modules[name].verify_freeze(manifest, phase, root / "gold.json")
                            row.update(accepted=True, native_matches_freeze=evidence["native_matches_freeze"])
                        except Exception as exc:
                            row.update(accepted=False, error={"type": type(exc).__name__, "message": str(exc)})
                        row["matches_expectation"] = row["accepted"] == expected
                        report["rows"].append(row)
                        record(json.dumps(row, sort_keys=True))
        report["summary"] = {
            "case_definitions": len(CASES), "phases": 2, "validations": len(report["rows"]),
            "expectation_matches": sum(row["matches_expectation"] for row in report["rows"]),
            "omission_categories_now_rejected": sum(before and not after for _, _, before, after in CASES),
            "per_implementation": {name: {
                "accepted": sum(row["accepted"] for row in report["rows"] if row["implementation"] == name),
                "rejected": sum(not row["accepted"] for row in report["rows"] if row["implementation"] == name),
            } for name in REVISIONS},
            "passed": all(row["matches_expectation"] for row in report["rows"]),
        }
        with (OUTPUT / "regression.json").open("x", encoding="utf-8") as output:
            json.dump(report, output, ensure_ascii=False, indent=2, allow_nan=False)
            output.write("\n")
        record("SUMMARY " + json.dumps(report["summary"], sort_keys=True))
    return 0 if report["summary"]["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
