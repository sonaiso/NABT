import gzip, hashlib, json, platform, re, shutil, subprocess, zipfile
from pathlib import Path

local=Path('artifacts/local/entropy')
out=Path('evidence/strategic_entropy_v1')
base='a14332afb934bedd4f35bf2fb3d34c9004df52b7'
code='180c198d233a6bf90f1968d6958a6771d234a7d2'
def read(path): return json.loads(path.read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
process=read(local/'full-tests-process.json')
assert process['exit_code']==0 and process['summary_present'] and process['success_marker_present']
log=(local/'full-tests.log').read_text()
total=int(re.search(r'Ran (\d+) tests in ',log)[1])
skipped=int(re.search(r'^OK \(skipped=(\d+)\)$',log,re.M)[1])
r=read(local/'replay/acquisition-regression.json')
assert r['contract_gate']['passed'] and r['representation_gate']['passed']
assert r['execution_evidence']['initial_snapshot_matches_freeze']
assert not r['execution_evidence']['loaded_hash_mismatches']
assert r['execution_evidence']['commit']==code
conf=read(local/'replay/licensed-inference-conformance.json');assert conf['pass'] and not conf['mismatches']
integration=read(local/'replay/acquired-inference.json');assert integration['passed']
before=read(local/'before.json');after=read(local/'after.json')
assert before['provenance']['commit']==base and after['provenance']['commit']==code
assert before['method']==after['method'] and after['boundary']['passed']
inventory=read(Path('artifacts/local/entropy-inventory/regression.json'))
assert inventory['summary']['passed'] and inventory['summary']['expectation_matches']==52
assert inventory['summary']['omission_categories_now_rejected']==7
trace=read(local/'traceability.json')
assert trace['acquisition_sources']['source_file_count']==5
assert trace['acquisition_sources']['verified_passage_count']==23
preserved=['src','formal','Makefile','tools/licensed_inference','integrations/current_proof_references.mk','evidence/aligned_acquisition_v1/integration']
subprocess.run(['git','diff','--exit-code',base,'HEAD','--',*preserved],check=True)
for src,name in [(local/'before.json','before.json.gz'),(local/'after.json','after.json.gz'),(local/'traceability.json','traceability.json.gz'),(local/'replay/acquisition-regression.json','acquisition-regression.json.gz')]:
 with (out/name).open('xb') as stream: stream.write(gzip.compress(src.read_bytes(),mtime=0))
with (out/'acquisition-freeze.json').open('xb') as stream: stream.write((local/'replay/acquisition-freeze.json').read_bytes())
with zipfile.ZipFile(out/'inventory_regression.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted(Path('artifacts/local/entropy-inventory').iterdir()):
  if p.is_file(): archive.write(p,p.name)
with zipfile.ZipFile(out/'validation_logs.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for name in ['full-tests.log','full-tests-process.json','native-gates.log','run_full_tests.py','package_evidence.py']:
  archive.write(local/name,name)
with zipfile.ZipFile(out/'gate_reports.zip','x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
 for p in sorted((local/'replay').glob('*.json')):
  if p.name not in ['acquisition-freeze.json','acquisition-regression.json']: archive.write(p,p.name)
receipt={
 'schema':'nabt.strategic-entropy-verification.v1', 'base_commit':base,'implementation_commit':code,
 'full_tests':{**process,'collected':total,'passed':total-skipped,'skipped':skipped},
 'static_audit':{'method_sha256':after['method']['source_sha256'],'same_method_for_both_commits':True,'boundary_passed':True,
   'before_population':before['population'],'after_population':after['population'],
   'all_literal_import_graph':{k:after['graphs']['all_imports'][k] for k in ['vertex_count','directed_edge_count','multi_node_strong_components','outdegree_entropy','layer_edge_counts']},
   'interpretation':'No entropy decrease or quality score claimed; the new analyzer adds one module.'},
 'freeze_inventory_counterexample':{'cases':13,'phases':2,'implementations':2,'matching_expected_observations':52,'newly_rejected_omission_categories':7,'scope':'Synthetic Git-backed verify_freeze only; dummy native bytes never execute and pins/ancestry are fixture overrides.'},
 'native_gates':{'command':'make -f tools/aligned_acquisition.mk grammar-catalog mantuq-inference linguistic-truth aligned-acquisition-evaluation LAKE=/path/to/lean-4.34.1-linux/bin/lake EVIDENCE_DIR=<new-output-directory>', 'exit_code_observed':0,
   'pr34_conformance_total':conf['total'],'pr34_conformance_passed':conf['pass'],
   'diagnostic':read(local/'replay/licensed-inference-benchmark.json')['summary'],
   'exposed_composition':{k:v for k,v in integration.items() if k!='rows'}},
 'acquisition_replay':{'summary':r['summary'],'contract_gate':r['contract_gate'],'representation_gate':r['representation_gate'],
   'initial_snapshot_matches_freeze':True,'no_loaded_hash_mismatches':True,'fresh_held_out_matrix':False},
 'source_traceability':{'source_linkage':trace['formal']['source_linkage'],'source_files':5,'exact_passages':23,
   'scope':'Source-matching stored compiled catalogue and replayed source metadata; standalone script does not rebuild Lean.'},
 'preserved_paths_against_base':preserved,
 'environment':{'python':platform.python_version(),'platform':platform.platform(),'toolchain':'leanprover/lean4:v4.34.1',
   'native_adapter':'LD_PRELOAD=/tmp/nabt_lean_proc_path.so','adapter_sha256':sha(Path('/tmp/nabt_lean_proc_path.so')),
   'adapter_explanation':'evidence/aligned_acquisition_v1/validation/environment.json',
   'native_hashes':read(local/'replay/acquisition-freeze.json')['native']},
 'limitations':['No new Arabic law, person or nominal goal contract, or general Python/Lean refinement theorem.',
   'Graphs omit dynamic/native/data and implicit package-initialization dependencies; mathematical graph invariants are descriptive.',
   'Missing authored links do not establish missing theorems; supplied-link resolution does not establish completeness.',
   'Sequential source hashes do not guarantee atomic isolation from concurrent writers.',
   'This is not a release and make check was not run as a single complete release command.'],
 'artifacts':{p.name:sha(p) for p in sorted(out.iterdir()) if p.is_file() and p.name not in ['verification.json','README.md']},
}
with (out/'verification.json').open('x') as stream: json.dump(receipt,stream,ensure_ascii=False,indent=2);stream.write('\n')
print(json.dumps({'tests':receipt['full_tests'],'output':str(out)}))
