import json,subprocess,time,re
from pathlib import Path
root=Path('artifacts/local/entropy')
started=time.monotonic()
with (root/'full-tests.log').open('w') as output:
    execution=subprocess.run(['make','test'],stdout=output,stderr=subprocess.STDOUT)
raw=(root/'full-tests.log').read_text()
summary=re.search(r'Ran (\d+) tests in ([0-9.]+)s',raw)
passed=re.search(r'^OK(?: \(skipped=(\d+)\))?$',raw,re.M)
receipt={'exit_code':execution.returncode,'seconds':time.monotonic()-started,'summary_present':summary is not None,'success_marker_present':passed is not None}
(root/'full-tests-process.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt),flush=True)
raise SystemExit(0 if execution.returncode==0 and summary and passed else 1)
