"""Capture exact native examples without reclassifying them as language gold."""
from pathlib import Path
import hashlib
import json
import sys

ROOT = Path('/workspace/scratch/8ead824583ac/NABT')
sys.path[:0] = [str(ROOT / 'src'), str(ROOT)]
from tools.linguistic_truth.surface import certify_surface
from nabt.classical_certified import evaluate_certified

cases = []
for name, text, expected in [
    ('witnessed_form', 'عَيْنَ', 'CHECKED_EXACT_SURFACE'),
    ('changed_vowel', 'عِيْنَ', 'DEFER'),
    ('missing_mark', 'عين', 'DEFER'),
    ('erased_separator_counterexample', 'عَ يْنَ', 'DEFER'),
    ('other_attested_verb', 'خَرَجَ', 'CHECKED_EXACT_SURFACE'),
]:
    result = certify_surface(text, context='documentary_form_demonstration')
    assert result['status'] == expected
    assert result['strict_language_accepted'] is False
    assert result['intended_sense_established'] is False
    assert bool(result['claims']) == (expected == 'CHECKED_EXACT_SURFACE')
    cases.append({'id': name, 'input': text, 'receipt': result})

raw = 'قَالَ: «عَيْنَ»'
start = raw.encode().index('عَيْنَ'.encode())
result = certify_surface(raw, start_byte=start, end_byte=start+len('عَيْنَ'.encode()),
    context='quotation_context_preserved_not_interpreted')
assert result['exact_surface_checked'] is True
assert result['intended_sense_established'] is False
cases.append({'id': 'quoted_occurrence', 'input': raw, 'receipt': result})

control = evaluate_certified('HAMZA-LEXICAL-COMMAND',
    {'root': ['ء', 'ك', 'ل'], 'profile': 'all_attested'})
assert control['status'] == 'CHECKED_CONDITIONAL_CONTROL'
assert control['strict_language_accepted'] is False

report = {'schema': 'nabt.progressive-rule-demonstrations.v1',
    'scope': 'Explicit development examples. These are neither independent linguistic gold nor a natural-use score. Native claims retain their conditional scope.',
    'surface_cases': cases, 'classical_control': control}
destination = ROOT / 'artifacts/local/progressive-rule-audit/native_examples.json'
destination.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'sha256': hashlib.sha256(destination.read_bytes()).hexdigest(),
    'surface_cases': [{'id': case['id'], 'status': case['receipt']['status'],
        'native_checked': case['receipt']['native_checked'],
        'witness_count': len(case['receipt']['matches'])} for case in cases],
    'classical': control['status']}, ensure_ascii=False))
