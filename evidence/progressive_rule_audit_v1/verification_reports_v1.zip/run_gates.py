import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

root = Path('/workspace/scratch/8ead824583ac/NABT')
destination = root / 'artifacts/local/progressive-rule-audit'
destination.mkdir(parents=True, exist_ok=True)
lake = '/workspace/scratch/041f7a0071c0/lean-driver/lake'
python = '/tmp/nabt-neural-ci-review/bin/python'
environment = dict(os.environ,
    PATH='/workspace/scratch/041f7a0071c0/lean-driver:' + os.environ['PATH'],
    NABT_QATR_READING=str(root / 'formal/.lake/build/bin/qatrReading'),
    NABT_LEXICAL_DENOTATION=str(root / 'formal/.lake/build/bin/lexicalDenotation'))
common = ['LAKE=' + lake, 'PYTHON=' + python]
commands = [
    ('make-check', ['make', 'check', '-o', 'test', *common,
        'EVIDENCE_DIR=artifacts/local/progressive-rule-audit/checks',
        'ARABIC_EVALUATION_DIR=artifacts/local/progressive-rule-audit/checks/arabic-regression']),
    ('unit-tests', ['make', 'test', *common]),
    ('integration', ['make', '-f', 'Makefile', '-f', 'integrations/grammar_catalog.mk',
        '-f', 'integrations/mantuq_inference.mk', '-f', 'integrations/linguistic_truth.mk',
        '-f', 'integrations/licensed_inference.mk', 'grammar-catalog', 'proof-catalog',
        'routing-conformance', 'mantuq-inference', 'linguistic-truth', 'licensed-inference',
        *common, 'EVIDENCE_DIR=artifacts/local/progressive-rule-audit/integration']),
]
records = []
for name, command in commands:
    print(json.dumps({'phase':name,'event':'START'}),flush=True)
    start = time.monotonic()
    log = destination / (name + '.log')
    with log.open('wb') as stream:
        result = subprocess.run(command, cwd=root, env=environment, stdout=stream,
                                stderr=subprocess.STDOUT, check=False)
    record = dict(name=name, command=command, returncode=result.returncode,
        elapsed_seconds=round(time.monotonic()-start, 3), log=str(log.relative_to(root)),
        log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
        explicit_environment={key: environment[key] for key in ('NABT_QATR_READING', 'NABT_LEXICAL_DENOTATION')})
    records.append(record)
    (destination / 'gates.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode:
        raise SystemExit(result.returncode)
