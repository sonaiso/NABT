# Independent bounded source-text evaluation: draft before grammar agreement

Reviewer: separate evaluation agent. Baseline repository commit:
`0182987c585edb3cb52959c167d3d2b16ebfd211`.

The reviewer read the preexisting public requirements, prior evaluation reports,
and original packaged sources. It has not read the forthcoming reader or
semantic-kernel implementations. Test text, gold answers, and this private
workspace must not be supplied to the implementing agents before code freeze.

## Independence boundary

The public grammar, semantic contract, result schema, and resource limits are
shared with the builders. Examples, gold labels, and selected negative cases are
separately authored. This is implementation-independent controlled evaluation;
it is neither an independently sampled Arabic corpus nor an unseen-book study.
The genuine book passages are reported separately and retain the original
packaged bytes. An authored restatement of a book must be labelled as a restated
annotation, never as a directly parsed source passage.

## Planned sample

Sixty controlled-Arabic episodes, ten per family:

1. New definitions and their use with unseen names and new property names.
2. Asserted unary facts, explicit negative facts, and irrelevant evidence.
3. Directed binary relations, variable joins, and a different relation topology.
4. Conditional rules, conjunction, multiple derivation routes, and chains.
5. Missing premises, conflicting evidence, and a named discriminating question.
6. Evidence withdrawal/replacement, affected dependents, and retained independent
   support.

Twelve genuine nonpilot source excerpts, four per packaged source, form a
separate natural-source coverage stratum. Their manifest includes byte ranges,
the raw text, full-source hashes, excerpt hashes, source attribution, and
reviewer interpretation notes.

Additional adversarial probes have separate denominators. They cover forged
source identity, forged span digest, non-byte-boundary intervals, subject/object
transfer, stale receipts, caller-defined authority, malformed syntax, duplicate
evidence, unsupported constructs, and deterministic resource deferral.

## Gold and freeze

Expected logical results are manually authored from the public semantic
contract. They do not call the production reader or inference implementation.
The evaluation adapter may depend on documented public API names, but adapter
changes after freeze must not change input text, expected results, or budgets.
The exact frozen dataset bytes, protocol, and file SHA-256 values are announced
before running the implementation. The code snapshot is recorded separately.

If a gold error or underspecified semantic case is discovered, retain the first
result and label a correction; do not silently replace the case or denominator.
If the implementation is fixed after test disclosure, the first frozen score
remains the heldout score and a later pass is a disclosed regression rerun.

## Scoring

Every episode has fixed input texts, query atoms, update operations, and expected
statuses. A complete episode succeeds only if all checkpoints match the gold.
Report complete episodes and checkpoint counts separately, by family.

Answer statuses distinguish positive-only, negative-only, unknown, conflicting,
invalid/unsupported input, and resource deferral. Exactly how downstream
conflicted premises behave is fixed before the test corpus is frozen.

- Justified precision: correct source-supported answered queries / all queries
  presented as justified answers.
- Justified coverage: correct source-supported answers / queries with sufficient
  consistent evidence under the declared contract.
- Missing-premise accuracy: exact relevant residuals / missing-evidence cases.
- Conflict handling: correctly identified conflicting cases / conflict cases.
- Revision fidelity: correctly recomputed checkpoints / revision checkpoints,
  including both affected and unaffected queries.
- Provenance safety: incorrectly accepted forged or transferred evidence / all
  declared attacks. Zero is a finite observed result, never a universal guarantee.
- Natural-source coverage: semantically successful raw excerpts / twelve.
  Safe abstention has zero semantic coverage but can satisfy a separate safety
  criterion. It must not be counted as successful natural-language understanding.

Timing, peak memory if measured, Python/platform identity, budgets, parse failure
counts, and first-run errors are retained. Confidence intervals, if presented,
are descriptive binomial intervals over this finite convenience sample; shared
templates and hand selection prohibit population-level generalization.

## Explicit nonclaims

This benchmark cannot establish arbitrary Arabic comprehension, factual truth
of source assertions, a new source's authority, general learned lexical
semantics, a universal Python refinement proof, or the proposed 300-episode
ROADMAP generality gate. Source-byte replay establishes that the cited material
was used; interpretation soundness has its own declared grammar and assumptions.
