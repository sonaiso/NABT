import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/6e4178bfef09/nabt_integration/NABT')
OUT = Path('/tmp/nabt_text_eval_private')
DATA = ROOT / 'src/nabt/data/source_evidence'

# Hand-selected literal excerpts from the original packaged bytes, separate
# from the six-noun pilot records. No reader implementation was consulted.
specs = [
    ('qatr_word_definition', 'qatr', 'الكلمة: قول مفرد. وهي اسم وفعل وحرف.', None,
     'word definition and three-way classification'),
    ('qatr_declension_definition', 'qatr', 'معرب وهو ما يتغير أواخره بسبب العوامل الداخلة عليه ك"زيد".', None,
     'definition with a relative clause and causal qualification'),
    ('qatr_speech_definition', 'qatr', 'والكلام: لفظ مفيد.', 'ك"قام زيد".',
     'speech definition and disjunction of minimal constructions'),
    ('qatr_particle_definition', 'qatr', 'وأما الحرف: فيعرف بأن لا يقبل شيئا من علامات الاسم والفعل', 'مبنية.',
     'negative characterization, exception, and universal property'),
    ('alfiyya_speech_definition', 'alfiyya', 'كلامنا لفظ مفيد كاستقم ... واسم وفعل ثم حرف الكلم', None,
     'verse: speech definition and word classes'),
    ('alfiyya_particle_property', 'alfiyya', 'وكل حرف مستحق للبنا ... والأصل في المبني أن يسكنا', None,
     'verse: universal particle property and construction default'),
    ('alfiyya_predicate_definition', 'alfiyya', 'والخبر الجزء المتم الفائدة ... كالله بر والأيادي شاهده', None,
     'verse: predicate definition with example'),
    ('alfiyya_declension_definition', 'alfiyya', 'ومعرب الأسماء ما قد سلما ... من شبه الحرف كأرض وسما', None,
     'verse: definition involving absence of similarity'),
    ('sibawayhi_word_classes', 'sibawayhi', 'فالكلم اسم وفعل وحرف جاء لمعنى ليس باسم ولا فعل', '~~وحائط',
     'word classes and noun examples'),
    ('sibawayhi_predication_dependence', 'sibawayhi', 'وهما ما لا يغنى واحد منهما عن الآخر ولا يجد المتكلم منه بدا', 'وهو قولك عبد الله أخوك وهذا أخوك',
     'binary mutual dependence with coreference to a chapter heading'),
    ('sibawayhi_definite_classes', 'sibawayhi', 'فالمعرفة خمسة أشياء الأسماء التي هي أعلام خاصة والمضاف إلى المعرفة [', 'والأسماء المبهمة والإضمار',
     'five definite-noun classes with an explicit qualification'),
    ('sibawayhi_genitive_relation', 'sibawayhi', 'والجر إنما يكون فى كل اسم مضاف إليه', None,
     'quantified property constrained by an attachment relation'),
]

records=[]
for ident, source_id, start_text, end_text, description in specs:
    raw=(DATA / f'{source_id}.txt').read_bytes()
    start_b=start_text.encode('utf-8')
    assert raw.count(start_b)==1, (ident, raw.count(start_b))
    start=raw.index(start_b)
    end=start+len(start_b) if end_text is None else raw.index(end_text.encode('utf-8'), start)+len(end_text.encode('utf-8'))
    chunk=raw[start:end]
    records.append({
        'id':ident,
        'stratum':'genuine_packaged_book_span',
        'source_id':source_id,
        'path':str((DATA / f'{source_id}.txt').relative_to(ROOT)),
        'source_sha256':hashlib.sha256(raw).hexdigest(),
        'source_bytes':len(raw),
        'start':start,
        'end':end,
        'byte_convention':'zero-based half-open UTF-8 bytes in unmodified packaged file',
        'span_sha256':hashlib.sha256(chunk).hexdigest(),
        'text':chunk.decode('utf-8'),
        'description':description,
        'selection':'Independent reviewer selected; the original books and selected topics are public to builders. Do not describe this stratum as an unseen book benchmark.',
        'interpretation':'Reviewer description only; not a source-certified semantic representation.',
    })
output={
    'schema':'nabt-independent-natural-source-candidates-v1',
    'scope':'Twelve genuine source spans for separate out-of-template coverage measurement. Actual expected semantic questions and parser scope must be frozen separately.',
    'license':'Original source-derived data remains CC BY-NC-SA 4.0; see packaged LICENSE-DATA.md.',
    'records':records,
}
path=OUT/'real_source_candidates.json'
path.write_text(json.dumps(output,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'records':[{k:v for k,v in r.items() if k in ('id','source_id','source_sha256','start','end','span_sha256')} for r in records]},ensure_ascii=False,indent=2))
